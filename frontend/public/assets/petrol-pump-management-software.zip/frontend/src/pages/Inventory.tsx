import { useState } from 'react';
import { useAppStore } from '../store/appStore';
import StockGauge from '../components/dashboard/StockGauge';
import StockAdjustmentModal from '../components/inventory/StockAdjustmentModal';
import ThresholdConfigModal from '../components/inventory/ThresholdConfigModal';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Settings, Plus, TrendingUp, TrendingDown, Package } from 'lucide-react';

export default function Inventory() {
  const stockLevels = useAppStore(s => s.stockLevels);
  const stockHistory = useAppStore(s => s.stockHistory);
  const [showAdjust, setShowAdjust] = useState(false);
  const [showThreshold, setShowThreshold] = useState(false);

  const lowStockAlerts = stockLevels.filter(s => s.currentLevel < s.threshold);

  return (
    <div className="space-y-6">
      {/* Actions */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {lowStockAlerts.length > 0 && (
            <div className="flex items-center gap-2 bg-amber/10 border border-amber/40 rounded-xl px-4 py-2">
              <AlertTriangle className="w-4 h-4 text-amber" />
              <span className="text-amber text-sm font-medium">{lowStockAlerts.length} fuel type(s) below threshold</span>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowThreshold(true)} className="border-navy-600 text-foreground hover:bg-navy-600">
            <Settings className="w-4 h-4 mr-2" />
            Thresholds
          </Button>
          <Button onClick={() => setShowAdjust(true)} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl">
            <Plus className="w-4 h-4 mr-2" />
            Adjust Stock
          </Button>
        </div>
      </div>

      {/* Stock Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stockLevels.map(stock => (
          <StockGauge key={stock.fuelType} {...stock} />
        ))}
      </div>

      {/* Summary Table */}
      <div className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
        <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
          <Package className="w-5 h-5 text-amber" />
          Stock Summary
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-navy-600">
                <th className="text-left text-muted-foreground py-2 pr-4">Fuel Type</th>
                <th className="text-right text-muted-foreground py-2 px-4">Current (L)</th>
                <th className="text-right text-muted-foreground py-2 px-4">Capacity (L)</th>
                <th className="text-right text-muted-foreground py-2 px-4">Threshold (L)</th>
                <th className="text-right text-muted-foreground py-2 px-4">Fill %</th>
                <th className="text-center text-muted-foreground py-2 pl-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {stockLevels.map(s => {
                const pct = ((s.currentLevel / s.capacity) * 100).toFixed(1);
                const isCritical = s.currentLevel < s.threshold * 0.5;
                const isLow = s.currentLevel < s.threshold;
                return (
                  <tr key={s.fuelType} className="border-b border-navy-600 last:border-0">
                    <td className="py-3 pr-4 font-medium text-foreground">{s.fuelType}</td>
                    <td className="py-3 px-4 text-right text-foreground">{s.currentLevel.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-muted-foreground">{s.capacity.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-amber">{s.threshold.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right text-foreground">{pct}%</td>
                    <td className="py-3 pl-4 text-center">
                      <Badge variant="outline" className={isCritical ? 'text-destructive border-destructive/40 bg-destructive/10' : isLow ? 'text-amber border-amber/40 bg-amber/10' : 'text-fuel-petrol border-fuel-petrol/40 bg-fuel-petrol/10'}>
                        {isCritical ? 'Critical' : isLow ? 'Low' : 'OK'}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock History */}
      <div className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
        <h3 className="font-display text-lg text-foreground mb-4">Stock Change History</h3>
        <div className="space-y-3 max-h-80 overflow-y-auto scrollbar-thin">
          {stockHistory.map(entry => (
            <div key={entry.id} className="flex items-start gap-4 py-3 border-b border-navy-600 last:border-0">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${entry.changeAmount > 0 ? 'bg-fuel-petrol/20' : 'bg-destructive/20'}`}>
                {entry.changeAmount > 0
                  ? <TrendingUp className="w-4 h-4 text-fuel-petrol" />
                  : <TrendingDown className="w-4 h-4 text-destructive" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-foreground">{entry.fuelType}</span>
                  <span className={`text-sm font-semibold ${entry.changeAmount > 0 ? 'text-fuel-petrol' : 'text-destructive'}`}>
                    {entry.changeAmount > 0 ? '+' : ''}{entry.changeAmount.toLocaleString()}L
                  </span>
                  <Badge variant="outline" className="text-xs text-muted-foreground border-navy-600">
                    {entry.type}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{entry.reason}</p>
                <p className="text-xs text-muted-foreground">By {entry.recordedBy} · {new Date(entry.date).toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <StockAdjustmentModal open={showAdjust} onClose={() => setShowAdjust(false)} />
      <ThresholdConfigModal open={showThreshold} onClose={() => setShowThreshold(false)} />
    </div>
  );
}
