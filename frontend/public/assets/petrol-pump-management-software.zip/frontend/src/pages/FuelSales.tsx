import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import RecordSaleModal from '../components/sales/RecordSaleModal';
import { Plus, Search } from 'lucide-react';
import type { FuelType, PaymentMethod } from '../types';

const ITEMS_PER_PAGE = 10;

export default function FuelSales() {
  const sales = useAppStore(s => s.sales);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  const [fuelFilter, setFuelFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState('');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    return sales.filter(s => {
      if (fuelFilter !== 'all' && s.fuelType !== fuelFilter) return false;
      if (paymentFilter !== 'all' && s.paymentMethod !== paymentFilter) return false;
      if (dateFilter && !s.date.startsWith(dateFilter)) return false;
      if (search && !s.id.toLowerCase().includes(search.toLowerCase()) && !s.staffName.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [sales, fuelFilter, paymentFilter, dateFilter, search]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  const fuelColors: Record<FuelType, string> = {
    Petrol: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
    Diesel: 'bg-fuel-diesel/20 text-fuel-diesel border-fuel-diesel/30',
    Premium: 'bg-amber/20 text-amber border-amber/30',
  };

  const paymentColors: Record<PaymentMethod, string> = {
    Cash: 'bg-fuel-petrol/20 text-fuel-petrol',
    Card: 'bg-fuel-diesel/20 text-fuel-diesel',
    Credit: 'bg-amber/20 text-amber',
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm">{filtered.length} transactions found</p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          className="bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
        >
          <Plus className="w-4 h-4 mr-2" />
          Record Sale
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 p-4 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by ID or staff..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            className="pl-9 bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <Input
          type="date"
          value={dateFilter}
          onChange={e => { setDateFilter(e.target.value); setPage(1); }}
          className="w-40 bg-navy-800 border-navy-600 text-foreground"
        />
        <Select value={fuelFilter} onValueChange={v => { setFuelFilter(v); setPage(1); }}>
          <SelectTrigger className="w-36 bg-navy-800 border-navy-600 text-foreground">
            <SelectValue placeholder="Fuel Type" />
          </SelectTrigger>
          <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
            <SelectItem value="all">All Fuels</SelectItem>
            <SelectItem value="Petrol">Petrol</SelectItem>
            <SelectItem value="Diesel">Diesel</SelectItem>
            <SelectItem value="Premium">Premium</SelectItem>
          </SelectContent>
        </Select>
        <Select value={paymentFilter} onValueChange={v => { setPaymentFilter(v); setPage(1); }}>
          <SelectTrigger className="w-36 bg-navy-800 border-navy-600 text-foreground">
            <SelectValue placeholder="Payment" />
          </SelectTrigger>
          <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
            <SelectItem value="all">All Payments</SelectItem>
            <SelectItem value="Cash">Cash</SelectItem>
            <SelectItem value="Card">Card</SelectItem>
            <SelectItem value="Credit">Credit</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-navy-600 hover:bg-transparent">
              <TableHead className="text-muted-foreground">Transaction ID</TableHead>
              <TableHead className="text-muted-foreground">Date & Time</TableHead>
              <TableHead className="text-muted-foreground">Fuel Type</TableHead>
              <TableHead className="text-muted-foreground">Quantity</TableHead>
              <TableHead className="text-muted-foreground">Price/L</TableHead>
              <TableHead className="text-muted-foreground">Total</TableHead>
              <TableHead className="text-muted-foreground">Payment</TableHead>
              <TableHead className="text-muted-foreground">Pump</TableHead>
              <TableHead className="text-muted-foreground">Staff</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginated.map(sale => (
              <TableRow key={sale.id} className="border-navy-600 hover:bg-navy-600/50">
                <TableCell className="text-amber font-mono text-xs">{sale.id.toUpperCase()}</TableCell>
                <TableCell className="text-foreground text-sm">
                  <div>{new Date(sale.date).toLocaleDateString('en-IN')}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(sale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={fuelColors[sale.fuelType]}>{sale.fuelType}</Badge>
                </TableCell>
                <TableCell className="text-foreground font-medium">{sale.quantity}L</TableCell>
                <TableCell className="text-foreground">
                  &#8377;{sale.pricePerLiter.toFixed(2)}
                </TableCell>
                <TableCell className="text-amber font-semibold">
                  &#8377;{sale.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${paymentColors[sale.paymentMethod]}`}>
                    {sale.paymentMethod}
                  </span>
                </TableCell>
                <TableCell className="text-foreground">#{sale.pumpNumber}</TableCell>
                <TableCell className="text-foreground text-sm">{sale.staffName}</TableCell>
              </TableRow>
            ))}
            {paginated.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-muted-foreground py-10">No sales found</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {totalPages} · {filtered.length} results
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="border-navy-600 text-foreground hover:bg-navy-600">Previous</Button>
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="border-navy-600 text-foreground hover:bg-navy-600">Next</Button>
          </div>
        </div>
      )}

      <RecordSaleModal open={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
}
