import { useState } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { useAppStore } from '../store/appStore';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Star, ShoppingBag, Gift } from 'lucide-react';
import RedeemPointsModal from '../components/customers/RedeemPointsModal';
import type { FuelType } from '../types';

export default function CustomerDetail() {
  const { customerId } = useParams({ from: '/layout/customers/$customerId' });
  const navigate = useNavigate();
  const customers = useAppStore(s => s.customers);
  const customerPurchases = useAppStore(s => s.customerPurchases);
  const [showRedeem, setShowRedeem] = useState(false);

  const customer = customers.find(c => c.id === customerId);
  const purchases = customerPurchases[customerId] ?? [];

  if (!customer) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Customer not found.</p>
        <Button onClick={() => navigate({ to: '/customers' })} className="mt-4 bg-amber text-navy-900">
          Back to Customers
        </Button>
      </div>
    );
  }

  const fuelColors: Record<FuelType, string> = {
    Petrol: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
    Diesel: 'bg-fuel-diesel/20 text-fuel-diesel border-fuel-diesel/30',
    Premium: 'bg-amber/20 text-amber border-amber/30',
  };

  return (
    <div className="space-y-6">
      {/* Back button */}
      <Button
        variant="ghost"
        onClick={() => navigate({ to: '/customers' })}
        className="text-muted-foreground hover:text-foreground -ml-2"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Customers
      </Button>

      {/* Customer Header */}
      <div className="bg-navy-700 rounded-2xl border border-navy-600 p-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber/20 flex items-center justify-center">
              <span className="font-display text-amber text-2xl font-bold">
                {customer.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
              </span>
            </div>
            <div>
              <h2 className="font-display text-2xl text-foreground">{customer.name}</h2>
              <p className="text-muted-foreground text-sm">{customer.contact}</p>
              <Badge variant="outline" className="mt-1 font-mono text-xs text-muted-foreground border-navy-600">
                {customer.vehicleNumber}
              </Badge>
            </div>
          </div>
          <Button
            onClick={() => setShowRedeem(true)}
            className="bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
          >
            <Gift className="w-4 h-4 mr-2" />
            Redeem Points
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="bg-navy-800 rounded-xl p-4 border border-navy-600">
            <p className="text-muted-foreground text-xs mb-1">Registered</p>
            <p className="text-foreground font-semibold">{new Date(customer.registrationDate).toLocaleDateString('en-IN')}</p>
          </div>
          <div className="bg-navy-800 rounded-xl p-4 border border-navy-600">
            <p className="text-muted-foreground text-xs mb-1">Total Volume</p>
            <p className="text-foreground font-semibold">{customer.totalPurchaseVolume.toLocaleString('en-IN')}L</p>
          </div>
          <div className="bg-amber/10 rounded-xl p-4 border border-amber/30">
            <p className="text-amber text-xs mb-1 flex items-center gap-1">
              <Star className="w-3 h-3" />
              Loyalty Points
            </p>
            <p className="text-amber font-display text-2xl font-bold">{customer.loyaltyPoints.toLocaleString('en-IN')}</p>
          </div>
        </div>
      </div>

      {/* Purchase History */}
      <div className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
        <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-amber" />
          Purchase History ({purchases.length})
        </h3>
        {purchases.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-8">No purchases yet</p>
        ) : (
          <div className="space-y-2">
            {purchases.map(p => (
              <div key={p.id} className="flex items-center justify-between py-3 border-b border-navy-600 last:border-0">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className={fuelColors[p.fuelType]}>{p.fuelType}</Badge>
                  <div>
                    <p className="text-sm text-foreground font-medium">{p.quantity}L</p>
                    <p className="text-xs text-muted-foreground">{new Date(p.date).toLocaleString('en-IN')}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-amber font-semibold">
                    &#8377;{p.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-muted-foreground flex items-center justify-end gap-1">
                    <Star className="w-3 h-3 text-amber" />
                    +{p.pointsEarned} pts
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <RedeemPointsModal open={showRedeem} onClose={() => setShowRedeem(false)} customer={customer} />
    </div>
  );
}
