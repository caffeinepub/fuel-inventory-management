import { useMemo } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAppStore } from '../store/appStore';
import MetricCard from '../components/dashboard/MetricCard';
import StockGauge from '../components/dashboard/StockGauge';
import { Fuel, IndianRupee, Users, AlertTriangle, TrendingUp, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function Dashboard() {
  const navigate = useNavigate();
  const sales = useAppStore(s => s.sales);
  const stockLevels = useAppStore(s => s.stockLevels);
  const shifts = useAppStore(s => s.shifts);
  const expenses = useAppStore(s => s.expenses);

  const today = new Date().toISOString().split('T')[0];

  const todaySales = useMemo(() => sales.filter(s => s.date.startsWith(today)), [sales, today]);
  const totalVolumeToday = useMemo(() => todaySales.reduce((sum, s) => sum + s.quantity, 0), [todaySales]);
  const totalRevenueToday = useMemo(() => todaySales.reduce((sum, s) => sum + s.totalAmount, 0), [todaySales]);
  const activeStaff = useMemo(() => shifts.filter(s => s.status === 'Active' && s.date === today).length, [shifts, today]);
  const lowStockAlerts = useMemo(() => stockLevels.filter(s => s.currentLevel < s.threshold), [stockLevels]);
  const monthlyExpenses = useMemo(() => {
    const thisMonth = new Date().toISOString().slice(0, 7);
    return expenses.filter(e => e.date.startsWith(thisMonth)).reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const recentSales = useMemo(() => sales.slice(0, 5), [sales]);

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden h-36 border border-navy-600">
        <img
          src="/assets/generated/dashboard-banner.dim_1200x300.png"
          alt="Dashboard Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 via-navy-900/60 to-transparent flex items-center px-8">
          <div>
            <h2 className="font-display text-3xl text-amber tracking-wider">STATION OVERVIEW</h2>
            <p className="text-muted-foreground text-sm mt-1">
              {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
        </div>
      </div>

      {/* Low Stock Alerts */}
      {lowStockAlerts.length > 0 && (
        <div className="bg-amber/10 border border-amber/40 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber flex-shrink-0 mt-0.5 animate-pulse" />
          <div>
            <p className="text-amber font-semibold text-sm">Low Stock Alert</p>
            <p className="text-muted-foreground text-xs mt-0.5">
              {lowStockAlerts.map(s => `${s.fuelType} (${s.currentLevel.toLocaleString('en-IN')}L)`).join(', ')} below threshold
            </p>
          </div>
          <button
            onClick={() => navigate({ to: '/inventory' })}
            className="ml-auto text-xs text-amber hover:underline flex-shrink-0"
          >
            View Inventory →
          </button>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Fuel Sold Today"
          value={totalVolumeToday.toLocaleString('en-IN')}
          unit="L"
          icon={Fuel}
          statusColor="amber"
          subtitle={`${todaySales.length} transactions`}
        />
        <MetricCard
          title="Revenue Today"
          value={`\u20B9${totalRevenueToday.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          icon={IndianRupee}
          statusColor="green"
          subtitle="Gross sales"
        />
        <MetricCard
          title="Active Staff"
          value={activeStaff}
          unit="on shift"
          icon={Users}
          statusColor="blue"
          subtitle="Currently working"
        />
        <MetricCard
          title="Monthly Expenses"
          value={`\u20B9${monthlyExpenses.toLocaleString('en-IN')}`}
          icon={TrendingUp}
          statusColor="red"
          subtitle="This month"
        />
      </div>

      {/* Stock Gauges */}
      <div>
        <h2 className="font-display text-xl text-foreground mb-4 flex items-center gap-2">
          <Fuel className="w-5 h-5 text-amber" />
          Fuel Stock Levels
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stockLevels.map(stock => (
            <StockGauge key={stock.fuelType} {...stock} />
          ))}
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Sales */}
        <div className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-lg text-foreground">Recent Sales</h3>
            <button onClick={() => navigate({ to: '/sales' })} className="text-xs text-amber hover:underline">View All →</button>
          </div>
          <div className="space-y-2">
            {recentSales.map(sale => (
              <div key={sale.id} className="flex items-center justify-between py-2 border-b border-navy-600 last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${sale.fuelType === 'Petrol' ? 'bg-fuel-petrol' : sale.fuelType === 'Diesel' ? 'bg-fuel-diesel' : 'bg-amber'}`} />
                  <div>
                    <p className="text-sm text-foreground font-medium">{sale.fuelType} — {sale.quantity}L</p>
                    <p className="text-xs text-muted-foreground">Pump {sale.pumpNumber} · {sale.staffName}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-amber">
                    &#8377;{sale.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(sale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Shifts */}
        <div className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-lg text-foreground">Today's Shifts</h3>
            <button onClick={() => navigate({ to: '/staff' })} className="text-xs text-amber hover:underline">Manage →</button>
          </div>
          <div className="space-y-2">
            {shifts.filter(s => s.date === today).map(shift => (
              <div key={shift.id} className="flex items-center justify-between py-2 border-b border-navy-600 last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${shift.status === 'Active' ? 'bg-fuel-petrol animate-pulse' : shift.status === 'Scheduled' ? 'bg-amber' : 'bg-muted-foreground'}`} />
                  <div>
                    <p className="text-sm text-foreground font-medium">{shift.staffName}</p>
                    <p className="text-xs text-muted-foreground">Pump {shift.pumpNumber} · {shift.startTime}–{shift.endTime}</p>
                  </div>
                </div>
                <Badge
                  variant={shift.status === 'Active' ? 'default' : 'secondary'}
                  className={shift.status === 'Active' ? 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30' : shift.status === 'Scheduled' ? 'bg-amber/20 text-amber border-amber/30' : ''}
                >
                  {shift.status}
                </Badge>
              </div>
            ))}
            {shifts.filter(s => s.date === today).length === 0 && (
              <p className="text-muted-foreground text-sm text-center py-4">No shifts scheduled today</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
