import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Plus, Truck, ShoppingCart, Edit2 } from 'lucide-react';
import SupplierFormModal from '../components/suppliers/SupplierFormModal';
import PurchaseOrderFormModal from '../components/suppliers/PurchaseOrderFormModal';
import type { Supplier, PurchaseOrder, OrderStatus, FuelType } from '../types';
import { toast } from 'sonner';

export default function Suppliers() {
  const suppliers = useAppStore(s => s.suppliers);
  const purchaseOrders = useAppStore(s => s.purchaseOrders);
  const updateOrderStatus = useAppStore(s => s.updateOrderStatus);

  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [orderDateFilter, setOrderDateFilter] = useState('');

  const filteredOrders = useMemo(() =>
    purchaseOrders.filter(o => {
      if (orderStatusFilter !== 'all' && o.status !== orderStatusFilter) return false;
      if (orderDateFilter && !o.orderDate.startsWith(orderDateFilter)) return false;
      return true;
    }).sort((a, b) => b.orderDate.localeCompare(a.orderDate)),
    [purchaseOrders, orderStatusFilter, orderDateFilter]
  );

  const statusColors: Record<OrderStatus, string> = {
    Pending: 'bg-amber/20 text-amber border-amber/30',
    Delivered: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
    Cancelled: 'bg-destructive/20 text-destructive border-destructive/30',
  };

  const fuelColors: Record<FuelType, string> = {
    Petrol: 'text-fuel-petrol',
    Diesel: 'text-fuel-diesel',
    Premium: 'text-amber',
  };

  return (
    <div className="space-y-5">
      <Tabs defaultValue="suppliers">
        <div className="flex items-center justify-between mb-4">
          <TabsList className="bg-navy-700 border border-navy-600">
            <TabsTrigger value="suppliers" className="data-[state=active]:bg-amber data-[state=active]:text-navy-900">
              <Truck className="w-4 h-4 mr-2" />
              Supplier Directory
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-amber data-[state=active]:text-navy-900">
              <ShoppingCart className="w-4 h-4 mr-2" />
              Purchase Orders
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Supplier Directory */}
        <TabsContent value="suppliers" className="space-y-4 mt-0">
          <div className="flex justify-end">
            <Button
              onClick={() => { setEditingSupplier(null); setShowSupplierModal(true); }}
              className="bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Supplier
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {suppliers.map((supplier: Supplier) => (
              <div key={supplier.id} className="bg-navy-700 rounded-2xl border border-navy-600 p-5 shadow-card">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber/20 flex items-center justify-center">
                    <Truck className="w-5 h-5 text-amber" />
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => { setEditingSupplier(supplier); setShowSupplierModal(true); }}
                    className="text-muted-foreground hover:text-amber h-7 w-7 p-0"
                  >
                    <Edit2 className="w-3 h-3" />
                  </Button>
                </div>
                <h3 className="font-semibold text-foreground">{supplier.name}</h3>
                <p className="text-muted-foreground text-sm mt-1">{supplier.contact}</p>
                <div className="flex flex-wrap gap-1 mt-3">
                  {supplier.fuelTypesSupplied.map(ft => (
                    <span
                      key={ft}
                      className={`text-xs px-2 py-0.5 rounded-full bg-navy-800 border border-navy-600 ${fuelColors[ft]}`}
                    >
                      {ft}
                    </span>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-navy-600">
                  <p className="text-xs text-muted-foreground">
                    {purchaseOrders.filter(o => o.supplierId === supplier.id).length} orders total
                  </p>
                </div>
              </div>
            ))}
            {suppliers.length === 0 && (
              <div className="col-span-3 text-center text-muted-foreground py-10">No suppliers added yet</div>
            )}
          </div>
        </TabsContent>

        {/* Purchase Orders */}
        <TabsContent value="orders" className="space-y-4 mt-0">
          <div className="flex items-center gap-3 flex-wrap">
            <Input
              type="date"
              value={orderDateFilter}
              onChange={e => setOrderDateFilter(e.target.value)}
              className="w-40 bg-navy-700 border-navy-600 text-foreground"
            />
            <Select value={orderStatusFilter} onValueChange={setOrderStatusFilter}>
              <SelectTrigger className="w-36 bg-navy-700 border-navy-600 text-foreground">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Delivered">Delivered</SelectItem>
                <SelectItem value="Cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={() => setShowOrderModal(true)}
              className="ml-auto bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Order
            </Button>
          </div>

          <div className="bg-navy-700 rounded-2xl border border-navy-600 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-navy-600">
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Order ID</th>
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Supplier</th>
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Fuel</th>
                    <th className="text-right text-muted-foreground py-3 px-4 whitespace-nowrap">Qty (L)</th>
                    <th className="text-right text-muted-foreground py-3 px-4 whitespace-nowrap">Total Cost</th>
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Order Date</th>
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Expected</th>
                    <th className="text-left text-muted-foreground py-3 px-4 whitespace-nowrap">Status</th>
                    <th className="py-3 px-4"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order: PurchaseOrder) => (
                    <tr key={order.id} className="border-b border-navy-600 last:border-0 hover:bg-navy-600/30">
                      <td className="py-3 px-4 text-amber font-mono text-xs">{order.id.toUpperCase()}</td>
                      <td className="py-3 px-4 text-foreground font-medium">{order.supplierName}</td>
                      <td className={`py-3 px-4 font-medium ${fuelColors[order.fuelType]}`}>{order.fuelType}</td>
                      <td className="py-3 px-4 text-right text-foreground">{order.quantityOrdered.toLocaleString('en-IN')}</td>
                      <td className="py-3 px-4 text-right text-amber font-semibold">
                        &#8377;{order.totalCost.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">{new Date(order.orderDate).toLocaleDateString('en-IN')}</td>
                      <td className="py-3 px-4 text-muted-foreground">{new Date(order.expectedDeliveryDate).toLocaleDateString('en-IN')}</td>
                      <td className="py-3 px-4">
                        <Badge variant="outline" className={statusColors[order.status]}>{order.status}</Badge>
                      </td>
                      <td className="py-3 px-4">
                        {order.status === 'Pending' && (
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                updateOrderStatus(order.id, 'Delivered');
                                toast.success('Order marked as Delivered — stock updated');
                              }}
                              className="text-xs border-fuel-petrol/40 text-fuel-petrol hover:bg-fuel-petrol/10 h-7 px-2"
                            >
                              Deliver
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                updateOrderStatus(order.id, 'Cancelled');
                                toast.success('Order cancelled');
                              }}
                              className="text-xs border-destructive/40 text-destructive hover:bg-destructive/10 h-7 px-2"
                            >
                              Cancel
                            </Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                  {filteredOrders.length === 0 && (
                    <tr>
                      <td colSpan={9} className="text-center text-muted-foreground py-10">No purchase orders found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <SupplierFormModal
        open={showSupplierModal}
        onClose={() => { setShowSupplierModal(false); setEditingSupplier(null); }}
        editingSupplier={editingSupplier}
      />
      <PurchaseOrderFormModal open={showOrderModal} onClose={() => setShowOrderModal(false)} />
    </div>
  );
}
