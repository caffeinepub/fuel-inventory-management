import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BarChart3, PieChart as PieIcon, TrendingUp, IndianRupee } from 'lucide-react';
import type { FuelType } from '../types';

const FUEL_COLORS: Record<FuelType, string> = {
  Petrol: '#4db8a0',
  Diesel: '#4da8d4',
  Premium: '#d4a84d',
};

export default function Reports() {
  const sales = useAppStore(s => s.sales);
  const expenses = useAppStore(s => s.expenses);

  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [expenseStartDate, setExpenseStartDate] = useState(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]
  );
  const [expenseEndDate, setExpenseEndDate] = useState(new Date().toISOString().split('T')[0]);

  // Daily Summary
  const dailySummary = useMemo(() => {
    const daySales = sales.filter(s => s.date.startsWith(selectedDate));
    const fuelTypes: FuelType[] = ['Petrol', 'Diesel', 'Premium'];
    return fuelTypes.map(ft => {
      const ftSales = daySales.filter(s => s.fuelType === ft);
      const volume = ftSales.reduce((sum, s) => sum + s.quantity, 0);
      const revenue = ftSales.reduce((sum, s) => sum + s.totalAmount, 0);
      return { fuelType: ft, volume, revenue, avgPrice: volume > 0 ? revenue / volume : 0 };
    });
  }, [sales, selectedDate]);

  // Monthly Trend (last 30 days)
  const monthlyTrend = useMemo(() => {
    const days: { day: string; revenue: number; volume: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().split('T')[0];
      const daySales = sales.filter(s => s.date.startsWith(d));
      days.push({
        day: new Date(d).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }),
        revenue: daySales.reduce((sum, s) => sum + s.totalAmount, 0),
        volume: daySales.reduce((sum, s) => sum + s.quantity, 0),
      });
    }
    return days;
  }, [sales]);

  // Fuel Type Breakdown
  const fuelBreakdown = useMemo(() => {
    const fuelTypes: FuelType[] = ['Petrol', 'Diesel', 'Premium'];
    return fuelTypes.map(ft => ({
      name: ft,
      value: sales.filter(s => s.fuelType === ft).reduce((sum, s) => sum + s.quantity, 0),
    })).filter(d => d.value > 0);
  }, [sales]);

  // Expense vs Revenue
  const expenseVsRevenue = useMemo(() => {
    const filteredSales = sales.filter(s => s.date >= expenseStartDate && s.date <= expenseEndDate);
    const filteredExpenses = expenses.filter(e => e.date >= expenseStartDate && e.date <= expenseEndDate);
    const revenue = filteredSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const expense = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    return [
      { name: 'Revenue', value: revenue },
      { name: 'Expenses', value: expense },
      { name: 'Net Profit', value: revenue - expense },
    ];
  }, [sales, expenses, expenseStartDate, expenseEndDate]);

  const tooltipStyle = {
    backgroundColor: 'oklch(0.20 0.025 250)',
    border: '1px solid oklch(0.28 0.03 250)',
    borderRadius: '8px',
    color: 'oklch(0.92 0.01 250)',
  };

  const formatINR = (v: number) =>
    '\u20B9' + v.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

  return (
    <div className="space-y-8">
      {/* Daily Summary */}
      <section className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <h3 className="font-display text-lg text-foreground flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber" />
            Daily Sales Summary
          </h3>
          <div className="flex items-center gap-2">
            <Label className="text-muted-foreground text-xs">Date:</Label>
            <Input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="w-40 bg-navy-800 border-navy-600 text-foreground"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-navy-600">
                <th className="text-left text-muted-foreground py-2 pr-4">Fuel Type</th>
                <th className="text-right text-muted-foreground py-2 px-4">Volume (L)</th>
                <th className="text-right text-muted-foreground py-2 px-4">Revenue (&#8377;)</th>
                <th className="text-right text-muted-foreground py-2 px-4">Avg Price (&#8377;/L)</th>
              </tr>
            </thead>
            <tbody>
              {dailySummary.map(row => (
                <tr key={row.fuelType} className="border-b border-navy-600 last:border-0">
                  <td className="py-3 pr-4 font-medium" style={{ color: FUEL_COLORS[row.fuelType] }}>{row.fuelType}</td>
                  <td className="py-3 px-4 text-right text-foreground">{row.volume.toLocaleString('en-IN')}</td>
                  <td className="py-3 px-4 text-right text-amber font-semibold">
                    &#8377;{row.revenue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-right text-muted-foreground">
                    &#8377;{row.avgPrice.toFixed(2)}
                  </td>
                </tr>
              ))}
              <tr className="bg-navy-800">
                <td className="py-3 pr-4 font-bold text-foreground">Total</td>
                <td className="py-3 px-4 text-right font-bold text-foreground">
                  {dailySummary.reduce((s, r) => s + r.volume, 0).toLocaleString('en-IN')}
                </td>
                <td className="py-3 px-4 text-right font-bold text-amber">
                  &#8377;{dailySummary.reduce((s, r) => s + r.revenue, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 px-4"></td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Monthly Trend */}
      <section className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
        <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-amber" />
          30-Day Sales Trend
        </h3>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={monthlyTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.03 250)" />
            <XAxis dataKey="day" tick={{ fill: 'oklch(0.58 0.02 250)', fontSize: 10 }} tickLine={false} interval={4} />
            <YAxis tick={{ fill: 'oklch(0.58 0.02 250)', fontSize: 10 }} tickLine={false} axisLine={false}
              tickFormatter={v => '\u20B9' + (v / 1000).toFixed(0) + 'k'} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [formatINR(v), 'Revenue']} />
            <Line type="monotone" dataKey="revenue" stroke="oklch(0.75 0.18 65)" strokeWidth={2}
              dot={false} activeDot={{ r: 4, fill: 'oklch(0.75 0.18 65)' }} />
          </LineChart>
        </ResponsiveContainer>
      </section>

      {/* Fuel Breakdown + Expense vs Revenue */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fuel Breakdown */}
        <section className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
          <h3 className="font-display text-lg text-foreground mb-4 flex items-center gap-2">
            <PieIcon className="w-5 h-5 text-amber" />
            Fuel Type Breakdown
          </h3>
          {fuelBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={fuelBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {fuelBreakdown.map(entry => (
                    <Cell key={entry.name} fill={FUEL_COLORS[entry.name as FuelType]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [`${v.toLocaleString('en-IN')}L`, 'Volume']} />
                <Legend formatter={(v) => <span style={{ color: 'oklch(0.92 0.01 250)', fontSize: 12 }}>{v}</span>} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-muted-foreground text-sm text-center py-16">No sales data available</p>
          )}
        </section>

        {/* Expense vs Revenue */}
        <section className="bg-navy-700 rounded-2xl border border-navy-600 p-5">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <h3 className="font-display text-lg text-foreground flex items-center gap-2">
              <IndianRupee className="w-5 h-5 text-amber" />
              Revenue vs Expenses
            </h3>
          </div>
          <div className="flex gap-2 mb-4 flex-wrap">
            <div className="flex items-center gap-1">
              <Label className="text-muted-foreground text-xs">From:</Label>
              <Input type="date" value={expenseStartDate} onChange={e => setExpenseStartDate(e.target.value)}
                className="w-36 bg-navy-800 border-navy-600 text-foreground text-xs h-8" />
            </div>
            <div className="flex items-center gap-1">
              <Label className="text-muted-foreground text-xs">To:</Label>
              <Input type="date" value={expenseEndDate} onChange={e => setExpenseEndDate(e.target.value)}
                className="w-36 bg-navy-800 border-navy-600 text-foreground text-xs h-8" />
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={expenseVsRevenue} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.03 250)" />
              <XAxis dataKey="name" tick={{ fill: 'oklch(0.58 0.02 250)', fontSize: 11 }} tickLine={false} />
              <YAxis tick={{ fill: 'oklch(0.58 0.02 250)', fontSize: 10 }} tickLine={false} axisLine={false}
                tickFormatter={v => '\u20B9' + (v / 1000).toFixed(0) + 'k'} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [formatINR(v)]} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {expenseVsRevenue.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={entry.name === 'Revenue' ? 'oklch(0.75 0.18 65)' : entry.name === 'Expenses' ? 'oklch(0.60 0.22 25)' : 'oklch(0.62 0.18 145)'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </section>
      </div>
    </div>
  );
}
