import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Eye } from 'lucide-react';
import InvoiceDetailModal from '../components/billing/InvoiceDetailModal';
import type { Invoice, InvoiceStatus } from '../types';

const ITEMS_PER_PAGE = 10;

export default function Billing() {
  const invoices = useAppStore(s => s.invoices);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState('');
  const [page, setPage] = useState(1);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const filtered = useMemo(() =>
    invoices.filter(inv => {
      if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
      if (dateFilter && !inv.date.startsWith(dateFilter)) return false;
      return true;
    }),
    [invoices, statusFilter, dateFilter]
  );

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  const statusColors: Record<InvoiceStatus, string> = {
    Paid: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
    Unpaid: 'bg-destructive/20 text-destructive border-destructive/30',
  };

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        {(['all', 'Paid', 'Unpaid'] as const).map(s => {
          const count = s === 'all' ? invoices.length : invoices.filter(i => i.status === s).length;
          const total = s === 'all'
            ? invoices.reduce((sum, i) => sum + i.total, 0)
            : invoices.filter(i => i.status === s).reduce((sum, i) => sum + i.total, 0);
          return (
            <div key={s} className="bg-navy-700 rounded-xl border border-navy-600 p-4">
              <p className="text-muted-foreground text-xs uppercase tracking-wider mb-1">
                {s === 'all' ? 'Total Invoices' : s}
              </p>
              <p className="font-display text-2xl text-foreground">{count}</p>
              <p className="text-amber text-sm font-medium">
                &#8377;{total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 p-4 flex gap-3 flex-wrap">
        <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-36 bg-navy-800 border-navy-600 text-foreground">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="Paid">Paid</SelectItem>
            <SelectItem value="Unpaid">Unpaid</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="date"
          value={dateFilter}
          onChange={e => { setDateFilter(e.target.value); setPage(1); }}
          className="w-40 bg-navy-800 border-navy-600 text-foreground"
        />
        <p className="text-muted-foreground text-sm self-center ml-auto">{filtered.length} invoices</p>
      </div>

      {/* Table */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-navy-600 hover:bg-transparent">
              <TableHead className="text-muted-foreground">Invoice #</TableHead>
              <TableHead className="text-muted-foreground">Date</TableHead>
              <TableHead className="text-muted-foreground">Customer</TableHead>
              <TableHead className="text-muted-foreground">Fuel</TableHead>
              <TableHead className="text-muted-foreground">Qty</TableHead>
              <TableHead className="text-muted-foreground">Total</TableHead>
              <TableHead className="text-muted-foreground">Payment</TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginated.map(inv => (
              <TableRow key={inv.id} className="border-navy-600 hover:bg-navy-600/50">
                <TableCell className="text-amber font-mono text-xs">{inv.invoiceNumber}</TableCell>
                <TableCell className="text-foreground text-sm">{new Date(inv.date).toLocaleDateString('en-IN')}</TableCell>
                <TableCell className="text-foreground text-sm">{inv.customerName}</TableCell>
                <TableCell className="text-foreground text-sm">{inv.fuelType}</TableCell>
                <TableCell className="text-foreground">{inv.quantity}L</TableCell>
                <TableCell className="text-amber font-semibold">
                  &#8377;{inv.total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">{inv.paymentMethod}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={statusColors[inv.status]}>{inv.status}</Badge>
                </TableCell>
                <TableCell>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setSelectedInvoice(inv)}
                    className="text-muted-foreground hover:text-amber h-7 w-7 p-0"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {paginated.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-muted-foreground py-10">No invoices found</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="border-navy-600 text-foreground hover:bg-navy-600">Previous</Button>
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="border-navy-600 text-foreground hover:bg-navy-600">Next</Button>
          </div>
        </div>
      )}

      {selectedInvoice && (
        <InvoiceDetailModal invoice={selectedInvoice} onClose={() => setSelectedInvoice(null)} />
      )}
    </div>
  );
}
