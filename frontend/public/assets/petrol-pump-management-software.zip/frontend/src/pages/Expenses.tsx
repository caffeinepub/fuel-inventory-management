import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { useGetCallerUserProfile } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Receipt, Loader2, IndianRupee } from 'lucide-react';
import { toast } from 'sonner';
import type { ExpenseCategory } from '../types';

const CATEGORY_COLORS: Record<ExpenseCategory, string> = {
  Maintenance: 'bg-fuel-diesel/20 text-fuel-diesel border-fuel-diesel/30',
  Utilities: 'bg-amber/20 text-amber border-amber/30',
  Salaries: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
  Other: 'bg-muted/20 text-muted-foreground border-muted/30',
};

const ITEMS_PER_PAGE = 10;

export default function Expenses() {
  const expenses = useAppStore(s => s.expenses);
  const addExpense = useAppStore(s => s.addExpense);
  const { data: profile } = useGetCallerUserProfile();

  const [showModal, setShowModal] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [page, setPage] = useState(1);

  // Modal state
  const [category, setCategory] = useState<ExpenseCategory>('Maintenance');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() =>
    expenses.filter(e => {
      if (categoryFilter !== 'all' && e.category !== categoryFilter) return false;
      if (startDate && e.date < startDate) return false;
      if (endDate && e.date > endDate) return false;
      return true;
    }),
    [expenses, categoryFilter, startDate, endDate]
  );

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthlyTotal = useMemo(() =>
    expenses
      .filter(e => e.date.startsWith(thisMonth))
      .reduce((sum, e) => sum + e.amount, 0),
    [expenses, thisMonth]
  );

  const categoryTotals = useMemo(() => {
    const cats: ExpenseCategory[] = ['Maintenance', 'Utilities', 'Salaries', 'Other'];
    return cats.map(cat => ({
      category: cat,
      total: expenses.filter(e => e.category === cat && e.date.startsWith(thisMonth)).reduce((s, e) => s + e.amount, 0),
    }));
  }, [expenses, thisMonth]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { toast.error('Enter a valid amount'); return; }
    if (!description.trim()) { toast.error('Description is required'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    addExpense({
      category,
      description,
      amount: amt,
      date: expenseDate,
      recordedBy: profile?.name || 'Manager',
    });
    toast.success('Expense recorded successfully');
    setSaving(false);
    setDescription('');
    setAmount('');
    setCategory('Maintenance');
    setExpenseDate(new Date().toISOString().split('T')[0]);
    setShowModal(false);
  };

  return (
    <div className="space-y-5">
      {/* Monthly Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-1 bg-amber/10 rounded-2xl border border-amber/30 p-4">
          <div className="flex items-center gap-2 mb-1">
            <IndianRupee className="w-4 h-4 text-amber" />
            <p className="text-amber text-xs font-medium uppercase tracking-wider">Monthly Total</p>
          </div>
          <p className="font-display text-2xl text-amber">
            &#8377;{monthlyTotal.toLocaleString('en-IN')}
          </p>
          <p className="text-muted-foreground text-xs mt-1">
            {new Date().toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
          </p>
        </div>
        {categoryTotals.map(ct => (
          <div key={ct.category} className="bg-navy-700 rounded-2xl border border-navy-600 p-4">
            <p className="text-muted-foreground text-xs uppercase tracking-wider mb-1">{ct.category}</p>
            <p className="font-display text-xl text-foreground">
              &#8377;{ct.total.toLocaleString('en-IN')}
            </p>
            <Badge variant="outline" className={`mt-1 text-xs ${CATEGORY_COLORS[ct.category]}`}>
              {ct.category}
            </Badge>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 p-4 flex flex-wrap gap-3 items-center">
        <Select value={categoryFilter} onValueChange={v => { setCategoryFilter(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-navy-800 border-navy-600 text-foreground">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Maintenance">Maintenance</SelectItem>
            <SelectItem value="Utilities">Utilities</SelectItem>
            <SelectItem value="Salaries">Salaries</SelectItem>
            <SelectItem value="Other">Other</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Label className="text-muted-foreground text-xs">From:</Label>
          <Input
            type="date"
            value={startDate}
            onChange={e => { setStartDate(e.target.value); setPage(1); }}
            className="w-36 bg-navy-800 border-navy-600 text-foreground"
          />
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-muted-foreground text-xs">To:</Label>
          <Input
            type="date"
            value={endDate}
            onChange={e => { setEndDate(e.target.value); setPage(1); }}
            className="w-36 bg-navy-800 border-navy-600 text-foreground"
          />
        </div>
        <p className="text-muted-foreground text-sm">{filtered.length} records</p>
        <Button
          onClick={() => setShowModal(true)}
          className="ml-auto bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
        >
          <Plus className="w-4 h-4 mr-2" />
          Record Expense
        </Button>
      </div>

      {/* Table */}
      <div className="bg-navy-700 rounded-xl border border-navy-600 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-navy-600 hover:bg-transparent">
              <TableHead className="text-muted-foreground">Date</TableHead>
              <TableHead className="text-muted-foreground">Category</TableHead>
              <TableHead className="text-muted-foreground">Description</TableHead>
              <TableHead className="text-muted-foreground">Recorded By</TableHead>
              <TableHead className="text-right text-muted-foreground">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginated.map(exp => (
              <TableRow key={exp.id} className="border-navy-600 hover:bg-navy-600/50">
                <TableCell className="text-foreground text-sm">{new Date(exp.date).toLocaleDateString('en-IN')}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={`text-xs ${CATEGORY_COLORS[exp.category]}`}>
                    {exp.category}
                  </Badge>
                </TableCell>
                <TableCell className="text-foreground text-sm">{exp.description}</TableCell>
                <TableCell className="text-muted-foreground text-sm">{exp.recordedBy}</TableCell>
                <TableCell className="text-right text-amber font-semibold">
                  &#8377;{exp.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
              </TableRow>
            ))}
            {paginated.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-10">No expenses found</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="border-navy-600 text-foreground hover:bg-navy-600">Previous</Button>
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="border-navy-600 text-foreground hover:bg-navy-600">Next</Button>
          </div>
        </div>
      )}

      {/* Record Expense Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-amber flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              Record Expense
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Category</Label>
              <Select value={category} onValueChange={v => setCategory(v as ExpenseCategory)}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Utilities">Utilities</SelectItem>
                  <SelectItem value="Salaries">Salaries</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Description *</Label>
              <Textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe the expense..."
                rows={2}
                required
                className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground text-xs mb-1.5 block">Amount (&#8377;) *</Label>
                <Input
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                  className="bg-navy-800 border-navy-600 text-foreground"
                />
              </div>
              <div>
                <Label className="text-muted-foreground text-xs mb-1.5 block">Date</Label>
                <Input
                  type="date"
                  value={expenseDate}
                  onChange={e => setExpenseDate(e.target.value)}
                  className="bg-navy-800 border-navy-600 text-foreground"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowModal(false)}
                className="border-navy-600 text-foreground hover:bg-navy-600">Cancel</Button>
              <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
                {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : 'Save Expense'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
