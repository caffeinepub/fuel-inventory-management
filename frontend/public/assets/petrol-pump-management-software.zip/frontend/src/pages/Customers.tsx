import { useState, useMemo } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAppStore } from '../store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Star, ChevronRight } from 'lucide-react';
import RegisterCustomerModal from '../components/customers/RegisterCustomerModal';

export default function Customers() {
  const customers = useAppStore(s => s.customers);
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');

  const filtered = useMemo(() =>
    customers.filter(c =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.vehicleNumber.toLowerCase().includes(search.toLowerCase()) ||
      c.contact.toLowerCase().includes(search.toLowerCase())
    ),
    [customers, search]
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or vehicle..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 bg-navy-700 border-navy-600 text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <p className="text-muted-foreground text-sm">{filtered.length} customers</p>
        <Button
          onClick={() => setShowModal(true)}
          className="ml-auto bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
        >
          <Plus className="w-4 h-4 mr-2" />
          Register Customer
        </Button>
      </div>

      <div className="bg-navy-700 rounded-2xl border border-navy-600 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-navy-600">
              <th className="text-left text-muted-foreground py-3 px-4">Customer</th>
              <th className="text-left text-muted-foreground py-3 px-4">Vehicle</th>
              <th className="text-left text-muted-foreground py-3 px-4">Contact</th>
              <th className="text-right text-muted-foreground py-3 px-4">Total Volume</th>
              <th className="text-right text-muted-foreground py-3 px-4">Loyalty Points</th>
              <th className="text-left text-muted-foreground py-3 px-4">Registered</th>
              <th className="py-3 px-4"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(customer => (
              <tr
                key={customer.id}
                className="border-b border-navy-600 last:border-0 hover:bg-navy-600/30 cursor-pointer"
                onClick={() => navigate({ to: '/customers/$customerId', params: { customerId: customer.id } })}
              >
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-amber/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-amber text-xs font-bold">
                        {customer.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                    <span className="font-medium text-foreground">{customer.name}</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <Badge variant="outline" className="text-muted-foreground border-navy-600 font-mono text-xs">
                    {customer.vehicleNumber}
                  </Badge>
                </td>
                <td className="py-3 px-4 text-muted-foreground">{customer.contact}</td>
                <td className="py-3 px-4 text-right text-foreground font-medium">{customer.totalPurchaseVolume.toLocaleString()}L</td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Star className="w-3 h-3 text-amber" />
                    <span className="text-amber font-semibold">{customer.loyaltyPoints.toLocaleString()}</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-muted-foreground text-xs">{new Date(customer.registrationDate).toLocaleDateString()}</td>
                <td className="py-3 px-4">
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="text-center text-muted-foreground py-10">No customers found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <RegisterCustomerModal open={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
}
