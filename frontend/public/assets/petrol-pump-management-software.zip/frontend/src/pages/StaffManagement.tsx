import { useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, UserCheck, Clock, Edit2, ToggleLeft } from 'lucide-react';
import StaffFormModal from '../components/staff/StaffFormModal';
import ShiftFormModal from '../components/staff/ShiftFormModal';
import type { Staff, Shift, ShiftStatus } from '../types';
import { toast } from 'sonner';

export default function StaffManagement() {
  const staff = useAppStore(s => s.staff);
  const shifts = useAppStore(s => s.shifts);
  const updateStaff = useAppStore(s => s.updateStaff);
  const updateShiftStatus = useAppStore(s => s.updateShiftStatus);

  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showShiftModal, setShowShiftModal] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);
  const [staffSearch, setStaffSearch] = useState('');
  const [shiftDateFilter, setShiftDateFilter] = useState('');
  const [shiftStatusFilter, setShiftStatusFilter] = useState<string>('all');

  const filteredStaff = useMemo(() =>
    staff.filter(s => s.name.toLowerCase().includes(staffSearch.toLowerCase()) || s.role.toLowerCase().includes(staffSearch.toLowerCase())),
    [staff, staffSearch]
  );

  const filteredShifts = useMemo(() =>
    shifts.filter(s => {
      if (shiftDateFilter && !s.date.startsWith(shiftDateFilter)) return false;
      if (shiftStatusFilter !== 'all' && s.status !== shiftStatusFilter) return false;
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date)),
    [shifts, shiftDateFilter, shiftStatusFilter]
  );

  const handleToggleStatus = (s: Staff) => {
    const newStatus = s.status === 'Active' ? 'Inactive' : 'Active';
    updateStaff(s.id, { status: newStatus });
    toast.success(`${s.name} marked as ${newStatus}`);
  };

  const shiftStatusColors: Record<ShiftStatus, string> = {
    Active: 'bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30',
    Scheduled: 'bg-amber/20 text-amber border-amber/30',
    Completed: 'bg-muted/20 text-muted-foreground border-muted/30',
  };

  return (
    <div className="space-y-5">
      <Tabs defaultValue="staff">
        <div className="flex items-center justify-between mb-4">
          <TabsList className="bg-navy-700 border border-navy-600">
            <TabsTrigger value="staff" className="data-[state=active]:bg-amber data-[state=active]:text-navy-900">
              <UserCheck className="w-4 h-4 mr-2" />
              Staff Directory
            </TabsTrigger>
            <TabsTrigger value="shifts" className="data-[state=active]:bg-amber data-[state=active]:text-navy-900">
              <Clock className="w-4 h-4 mr-2" />
              Shift Schedule
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Staff Directory */}
        <TabsContent value="staff" className="space-y-4 mt-0">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search staff..."
                value={staffSearch}
                onChange={e => setStaffSearch(e.target.value)}
                className="pl-9 bg-navy-700 border-navy-600 text-foreground placeholder:text-muted-foreground"
              />
            </div>
            <Button
              onClick={() => { setEditingStaff(null); setShowStaffModal(true); }}
              className="bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Staff
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStaff.map(member => (
              <div key={member.id} className="bg-navy-700 rounded-2xl border border-navy-600 p-5 shadow-card">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber/20 flex items-center justify-center">
                    <span className="font-display text-amber font-bold text-lg">
                      {member.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </span>
                  </div>
                  <Badge
                    variant="outline"
                    className={member.status === 'Active'
                      ? 'text-fuel-petrol border-fuel-petrol/40 bg-fuel-petrol/10'
                      : 'text-muted-foreground border-muted/40 bg-muted/10'}
                  >
                    {member.status}
                  </Badge>
                </div>
                <h3 className="font-semibold text-foreground">{member.name}</h3>
                <p className="text-amber text-sm">{member.role}</p>
                <p className="text-muted-foreground text-xs mt-1">{member.contact}</p>
                <p className="text-muted-foreground text-xs">Hired: {new Date(member.hireDate).toLocaleDateString()}</p>
                <div className="flex gap-2 mt-4">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => { setEditingStaff(member); setShowStaffModal(true); }}
                    className="flex-1 border-navy-600 text-foreground hover:bg-navy-600 text-xs"
                  >
                    <Edit2 className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleToggleStatus(member)}
                    className="flex-1 border-navy-600 text-foreground hover:bg-navy-600 text-xs"
                  >
                    <ToggleLeft className="w-3 h-3 mr-1" />
                    {member.status === 'Active' ? 'Deactivate' : 'Activate'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Shift Schedule */}
        <TabsContent value="shifts" className="space-y-4 mt-0">
          <div className="flex items-center gap-3 flex-wrap">
            <Input
              type="date"
              value={shiftDateFilter}
              onChange={e => setShiftDateFilter(e.target.value)}
              className="w-40 bg-navy-700 border-navy-600 text-foreground"
            />
            <Select value={shiftStatusFilter} onValueChange={setShiftStatusFilter}>
              <SelectTrigger className="w-36 bg-navy-700 border-navy-600 text-foreground">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Scheduled">Scheduled</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={() => setShowShiftModal(true)}
              className="ml-auto bg-amber text-navy-900 hover:bg-amber-light font-semibold rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Shift
            </Button>
          </div>

          <div className="bg-navy-700 rounded-2xl border border-navy-600 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-navy-600">
                  <th className="text-left text-muted-foreground py-3 px-4">Staff Member</th>
                  <th className="text-left text-muted-foreground py-3 px-4">Date</th>
                  <th className="text-left text-muted-foreground py-3 px-4">Time</th>
                  <th className="text-left text-muted-foreground py-3 px-4">Pump</th>
                  <th className="text-left text-muted-foreground py-3 px-4">Status</th>
                  <th className="text-left text-muted-foreground py-3 px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredShifts.map((shift: Shift) => (
                  <tr key={shift.id} className="border-b border-navy-600 last:border-0 hover:bg-navy-600/30">
                    <td className="py-3 px-4 font-medium text-foreground">{shift.staffName}</td>
                    <td className="py-3 px-4 text-foreground">{new Date(shift.date).toLocaleDateString()}</td>
                    <td className="py-3 px-4 text-foreground">{shift.startTime} – {shift.endTime}</td>
                    <td className="py-3 px-4 text-foreground">#{shift.pumpNumber}</td>
                    <td className="py-3 px-4">
                      <Badge variant="outline" className={shiftStatusColors[shift.status]}>
                        {shift.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      {shift.status === 'Scheduled' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { updateShiftStatus(shift.id, 'Active'); toast.success('Shift marked as Active'); }}
                          className="text-xs border-navy-600 text-foreground hover:bg-navy-600 h-7"
                        >
                          Start
                        </Button>
                      )}
                      {shift.status === 'Active' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { updateShiftStatus(shift.id, 'Completed'); toast.success('Shift completed'); }}
                          className="text-xs border-navy-600 text-foreground hover:bg-navy-600 h-7"
                        >
                          Complete
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
                {filteredShifts.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center text-muted-foreground py-10">No shifts found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>

      <StaffFormModal
        open={showStaffModal}
        onClose={() => { setShowStaffModal(false); setEditingStaff(null); }}
        editingStaff={editingStaff}
      />
      <ShiftFormModal open={showShiftModal} onClose={() => setShowShiftModal(false)} />
    </div>
  );
}
