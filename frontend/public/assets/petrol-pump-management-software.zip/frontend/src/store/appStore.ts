import { create } from 'zustand';
import type {
  FuelSale, StockLevel, StockHistoryEntry, Staff, Shift,
  Customer, CustomerPurchase, Invoice, Supplier, PurchaseOrder, Expense,
  FuelType, ShiftStatus, OrderStatus, InvoiceStatus
} from '../types';

// ── Seed Data ─────────────────────────────────────────────────────────────────
const today = new Date().toISOString().split('T')[0];
const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
const twoDaysAgo = new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0];

const seedStaff: Staff[] = [
  { id: 's1', name: 'Ahmed Hassan', role: 'Manager', contact: '+91-98765-43210', hireDate: '2021-03-15', status: 'Active' },
  { id: 's2', name: 'Maria Santos', role: 'Pump Attendant', contact: '+91-98765-43211', hireDate: '2022-06-01', status: 'Active' },
  { id: 's3', name: 'James Okafor', role: 'Pump Attendant', contact: '+91-98765-43212', hireDate: '2022-08-20', status: 'Active' },
  { id: 's4', name: 'Priya Patel', role: 'Cashier', contact: '+91-98765-43213', hireDate: '2023-01-10', status: 'Active' },
  { id: 's5', name: 'Carlos Rivera', role: 'Pump Attendant', contact: '+91-98765-43214', hireDate: '2023-05-15', status: 'Inactive' },
];

const seedShifts: Shift[] = [
  { id: 'sh1', staffId: 's2', staffName: 'Maria Santos', date: today, startTime: '06:00', endTime: '14:00', pumpNumber: 1, status: 'Active' },
  { id: 'sh2', staffId: 's3', staffName: 'James Okafor', date: today, startTime: '06:00', endTime: '14:00', pumpNumber: 2, status: 'Active' },
  { id: 'sh3', staffId: 's4', staffName: 'Priya Patel', date: today, startTime: '14:00', endTime: '22:00', pumpNumber: 3, status: 'Scheduled' },
  { id: 'sh4', staffId: 's2', staffName: 'Maria Santos', date: yesterday, startTime: '06:00', endTime: '14:00', pumpNumber: 1, status: 'Completed' },
  { id: 'sh5', staffId: 's3', staffName: 'James Okafor', date: yesterday, startTime: '14:00', endTime: '22:00', pumpNumber: 2, status: 'Completed' },
];

const seedCustomers: Customer[] = [
  { id: 'c1', name: 'Rajesh Kumar', contact: '+91-98765-43201', vehicleNumber: 'MH-01-AB-1234', registrationDate: '2023-01-15', totalPurchaseVolume: 1250, loyaltyPoints: 1250 },
  { id: 'c2', name: 'Priya Sharma', contact: '+91-98765-43202', vehicleNumber: 'DL-05-XY-5678', registrationDate: '2023-03-22', totalPurchaseVolume: 890, loyaltyPoints: 890 },
  { id: 'c3', name: 'Amit Patel', contact: '+91-98765-43203', vehicleNumber: 'GJ-01-DE-9012', registrationDate: '2022-11-08', totalPurchaseVolume: 2100, loyaltyPoints: 2100 },
  { id: 'c4', name: 'Sunita Rao', contact: '+91-98765-43204', vehicleNumber: 'KA-03-GH-3456', registrationDate: '2024-02-14', totalPurchaseVolume: 340, loyaltyPoints: 340 },
];

const seedSales: FuelSale[] = [
  { id: 'sale1', date: `${today}T08:15:00`, fuelType: 'Petrol', quantity: 45, pricePerLiter: 102.50, totalAmount: 4612.50, paymentMethod: 'Cash', pumpNumber: 1, staffId: 's2', staffName: 'Maria Santos', customerId: 'c1', customerName: 'Rajesh Kumar', invoiceId: 'inv1' },
  { id: 'sale2', date: `${today}T09:30:00`, fuelType: 'Diesel', quantity: 80, pricePerLiter: 89.75, totalAmount: 7180.00, paymentMethod: 'Card', pumpNumber: 2, staffId: 's3', staffName: 'James Okafor', invoiceId: 'inv2' },
  { id: 'sale3', date: `${today}T10:45:00`, fuelType: 'Premium', quantity: 30, pricePerLiter: 110.00, totalAmount: 3300.00, paymentMethod: 'Cash', pumpNumber: 1, staffId: 's2', staffName: 'Maria Santos', customerId: 'c2', customerName: 'Priya Sharma', invoiceId: 'inv3' },
  { id: 'sale4', date: `${today}T11:20:00`, fuelType: 'Petrol', quantity: 55, pricePerLiter: 102.50, totalAmount: 5637.50, paymentMethod: 'Card', pumpNumber: 3, staffId: 's4', staffName: 'Priya Patel', invoiceId: 'inv4' },
  { id: 'sale5', date: `${today}T12:00:00`, fuelType: 'Diesel', quantity: 100, pricePerLiter: 89.75, totalAmount: 8975.00, paymentMethod: 'Credit', pumpNumber: 2, staffId: 's3', staffName: 'James Okafor', customerId: 'c3', customerName: 'Amit Patel', invoiceId: 'inv5' },
  { id: 'sale6', date: `${yesterday}T08:00:00`, fuelType: 'Petrol', quantity: 40, pricePerLiter: 102.50, totalAmount: 4100.00, paymentMethod: 'Cash', pumpNumber: 1, staffId: 's2', staffName: 'Maria Santos', invoiceId: 'inv6' },
  { id: 'sale7', date: `${yesterday}T10:30:00`, fuelType: 'Premium', quantity: 25, pricePerLiter: 110.00, totalAmount: 2750.00, paymentMethod: 'Card', pumpNumber: 2, staffId: 's3', staffName: 'James Okafor', customerId: 'c4', customerName: 'Sunita Rao', invoiceId: 'inv7' },
  { id: 'sale8', date: `${twoDaysAgo}T09:15:00`, fuelType: 'Diesel', quantity: 120, pricePerLiter: 89.75, totalAmount: 10770.00, paymentMethod: 'Cash', pumpNumber: 1, staffId: 's2', staffName: 'Maria Santos', invoiceId: 'inv8' },
];

const seedStockLevels: StockLevel[] = [
  { fuelType: 'Petrol', currentLevel: 8500, capacity: 20000, threshold: 3000 },
  { fuelType: 'Diesel', currentLevel: 2200, capacity: 25000, threshold: 3000 },
  { fuelType: 'Premium', currentLevel: 1100, capacity: 10000, threshold: 1500 },
];

const seedStockHistory: StockHistoryEntry[] = [
  { id: 'hist1', date: `${today}T08:15:00`, fuelType: 'Petrol', changeAmount: -45, reason: 'Sale #sale1', recordedBy: 'Maria Santos', type: 'sale' },
  { id: 'hist2', date: `${today}T09:30:00`, fuelType: 'Diesel', changeAmount: -80, reason: 'Sale #sale2', recordedBy: 'James Okafor', type: 'sale' },
  { id: 'hist3', date: `${yesterday}T07:00:00`, fuelType: 'Petrol', changeAmount: 5000, reason: 'Delivery from PetroSupply Co.', recordedBy: 'Ahmed Hassan', type: 'purchase' },
  { id: 'hist4', date: `${twoDaysAgo}T06:00:00`, fuelType: 'Diesel', changeAmount: 8000, reason: 'Delivery from FuelMaster Ltd.', recordedBy: 'Ahmed Hassan', type: 'purchase' },
];

const seedInvoices: Invoice[] = [
  { id: 'inv1', invoiceNumber: 'INV-2024-001', date: `${today}T08:15:00`, customerId: 'c1', customerName: 'Rajesh Kumar', saleId: 'sale1', fuelType: 'Petrol', quantity: 45, pricePerLiter: 102.50, subtotal: 4612.50, tax: 461.25, total: 5073.75, paymentMethod: 'Cash', status: 'Paid' },
  { id: 'inv2', invoiceNumber: 'INV-2024-002', date: `${today}T09:30:00`, customerName: 'Walk-in', saleId: 'sale2', fuelType: 'Diesel', quantity: 80, pricePerLiter: 89.75, subtotal: 7180.00, tax: 718.00, total: 7898.00, paymentMethod: 'Card', status: 'Paid' },
  { id: 'inv3', invoiceNumber: 'INV-2024-003', date: `${today}T10:45:00`, customerId: 'c2', customerName: 'Priya Sharma', saleId: 'sale3', fuelType: 'Premium', quantity: 30, pricePerLiter: 110.00, subtotal: 3300.00, tax: 330.00, total: 3630.00, paymentMethod: 'Cash', status: 'Paid' },
  { id: 'inv4', invoiceNumber: 'INV-2024-004', date: `${today}T11:20:00`, customerName: 'Walk-in', saleId: 'sale4', fuelType: 'Petrol', quantity: 55, pricePerLiter: 102.50, subtotal: 5637.50, tax: 563.75, total: 6201.25, paymentMethod: 'Card', status: 'Unpaid' },
  { id: 'inv5', invoiceNumber: 'INV-2024-005', date: `${today}T12:00:00`, customerId: 'c3', customerName: 'Amit Patel', saleId: 'sale5', fuelType: 'Diesel', quantity: 100, pricePerLiter: 89.75, subtotal: 8975.00, tax: 897.50, total: 9872.50, paymentMethod: 'Credit', status: 'Unpaid' },
  { id: 'inv6', invoiceNumber: 'INV-2024-006', date: `${yesterday}T08:00:00`, customerName: 'Walk-in', saleId: 'sale6', fuelType: 'Petrol', quantity: 40, pricePerLiter: 102.50, subtotal: 4100.00, tax: 410.00, total: 4510.00, paymentMethod: 'Cash', status: 'Paid' },
];

const seedSuppliers: Supplier[] = [
  { id: 'sup1', name: 'Indian Oil Corporation', contact: '+91-22-2222-1111', fuelTypesSupplied: ['Petrol', 'Premium'] },
  { id: 'sup2', name: 'Bharat Petroleum', contact: '+91-22-2222-2222', fuelTypesSupplied: ['Diesel', 'Petrol'] },
  { id: 'sup3', name: 'Hindustan Petroleum', contact: '+91-22-2222-3333', fuelTypesSupplied: ['Petrol', 'Diesel', 'Premium'] },
];

const seedPurchaseOrders: PurchaseOrder[] = [
  { id: 'po1', supplierId: 'sup1', supplierName: 'Indian Oil Corporation', fuelType: 'Petrol', quantityOrdered: 10000, pricePerLiter: 85.00, totalCost: 850000, orderDate: yesterday, expectedDeliveryDate: today, status: 'Delivered' },
  { id: 'po2', supplierId: 'sup2', supplierName: 'Bharat Petroleum', fuelType: 'Diesel', quantityOrdered: 15000, pricePerLiter: 75.00, totalCost: 1125000, orderDate: today, expectedDeliveryDate: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0], status: 'Pending' },
  { id: 'po3', supplierId: 'sup3', supplierName: 'Hindustan Petroleum', fuelType: 'Premium', quantityOrdered: 5000, pricePerLiter: 92.00, totalCost: 460000, orderDate: twoDaysAgo, expectedDeliveryDate: yesterday, status: 'Delivered' },
];

const seedExpenses: Expense[] = [
  { id: 'exp1', category: 'Utilities', description: 'Monthly electricity bill', amount: 18500, date: today, recordedBy: 'Ahmed Hassan' },
  { id: 'exp2', category: 'Maintenance', description: 'Pump #2 filter replacement', amount: 8200, date: yesterday, recordedBy: 'Ahmed Hassan' },
  { id: 'exp3', category: 'Salaries', description: 'Staff salaries - February', amount: 125000, date: twoDaysAgo, recordedBy: 'Ahmed Hassan' },
  { id: 'exp4', category: 'Other', description: 'Office supplies', amount: 3450, date: twoDaysAgo, recordedBy: 'Priya Patel' },
];

const seedCustomerPurchases: Record<string, CustomerPurchase[]> = {
  c1: [
    { id: 'cp1', date: `${today}T08:15:00`, fuelType: 'Petrol', quantity: 45, amount: 4612.50, pointsEarned: 45 },
    { id: 'cp2', date: `${yesterday}T14:00:00`, fuelType: 'Diesel', quantity: 30, amount: 2692.50, pointsEarned: 30 },
  ],
  c2: [
    { id: 'cp3', date: `${today}T10:45:00`, fuelType: 'Premium', quantity: 30, amount: 3300.00, pointsEarned: 30 },
  ],
  c3: [
    { id: 'cp4', date: `${today}T12:00:00`, fuelType: 'Diesel', quantity: 100, amount: 8975.00, pointsEarned: 100 },
  ],
  c4: [
    { id: 'cp5', date: `${yesterday}T10:30:00`, fuelType: 'Premium', quantity: 25, amount: 2750.00, pointsEarned: 25 },
  ],
};

// ── Store Interface ───────────────────────────────────────────────────────────
export interface AppState {
  sales: FuelSale[];
  addSale: (sale: Omit<FuelSale, 'id' | 'invoiceId'>) => void;

  stockLevels: StockLevel[];
  stockHistory: StockHistoryEntry[];
  adjustStock: (fuelType: FuelType, amount: number, reason: string, recordedBy: string) => void;
  updateThreshold: (fuelType: FuelType, threshold: number) => void;

  staff: Staff[];
  addStaff: (staff: Omit<Staff, 'id'>) => void;
  updateStaff: (id: string, updates: Partial<Staff>) => void;

  shifts: Shift[];
  addShift: (shift: Omit<Shift, 'id'>) => void;
  updateShiftStatus: (id: string, status: ShiftStatus) => void;

  customers: Customer[];
  customerPurchases: Record<string, CustomerPurchase[]>;
  addCustomer: (customer: Omit<Customer, 'id' | 'registrationDate' | 'totalPurchaseVolume' | 'loyaltyPoints'>) => void;
  redeemPoints: (customerId: string, points: number) => void;

  invoices: Invoice[];
  toggleInvoiceStatus: (id: string) => void;

  suppliers: Supplier[];
  addSupplier: (supplier: Omit<Supplier, 'id'>) => void;
  updateSupplier: (id: string, updates: Partial<Omit<Supplier, 'id'>>) => void;

  purchaseOrders: PurchaseOrder[];
  addPurchaseOrder: (order: Omit<PurchaseOrder, 'id'>) => void;
  updateOrderStatus: (id: string, status: OrderStatus) => void;

  expenses: Expense[];
  addExpense: (expense: Omit<Expense, 'id'>) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  sales: seedSales,
  addSale: (saleData) => {
    const id = `sale${Date.now()}`;
    const invoiceId = `inv${Date.now()}`;
    const sale: FuelSale = { id, invoiceId, ...saleData };

    // Auto-generate invoice
    const subtotal = saleData.totalAmount;
    const tax = parseFloat((subtotal * 0.10).toFixed(2));
    const total = parseFloat((subtotal + tax).toFixed(2));
    const invoiceNumber = `INV-${new Date().getFullYear()}-${String(get().invoices.length + 1).padStart(3, '0')}`;
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      date: saleData.date,
      customerId: saleData.customerId,
      customerName: saleData.customerName || 'Walk-in',
      saleId: id,
      fuelType: saleData.fuelType,
      quantity: saleData.quantity,
      pricePerLiter: saleData.pricePerLiter,
      subtotal,
      tax,
      total,
      paymentMethod: saleData.paymentMethod,
      status: 'Paid',
    };

    // Update stock
    const updatedStockLevels = get().stockLevels.map(s =>
      s.fuelType === saleData.fuelType
        ? { ...s, currentLevel: Math.max(0, s.currentLevel - saleData.quantity) }
        : s
    );

    // Stock history entry
    const histEntry: StockHistoryEntry = {
      id: `hist${Date.now()}`,
      date: saleData.date,
      fuelType: saleData.fuelType,
      changeAmount: -saleData.quantity,
      reason: `Sale #${id}`,
      recordedBy: saleData.staffName,
      type: 'sale',
    };

    // Update customer purchase if applicable
    let updatedCustomerPurchases = { ...get().customerPurchases };
    let updatedCustomers = get().customers;
    if (saleData.customerId) {
      const purchase: CustomerPurchase = {
        id: `cp${Date.now()}`,
        date: saleData.date,
        fuelType: saleData.fuelType,
        quantity: saleData.quantity,
        amount: saleData.totalAmount,
        pointsEarned: Math.floor(saleData.quantity),
      };
      const existing = updatedCustomerPurchases[saleData.customerId] ?? [];
      updatedCustomerPurchases = {
        ...updatedCustomerPurchases,
        [saleData.customerId]: [purchase, ...existing],
      };
      updatedCustomers = updatedCustomers.map(c =>
        c.id === saleData.customerId
          ? {
              ...c,
              totalPurchaseVolume: c.totalPurchaseVolume + saleData.quantity,
              loyaltyPoints: c.loyaltyPoints + Math.floor(saleData.quantity),
            }
          : c
      );
    }

    set(state => ({
      sales: [sale, ...state.sales],
      invoices: [newInvoice, ...state.invoices],
      stockLevels: updatedStockLevels,
      stockHistory: [histEntry, ...state.stockHistory],
      customerPurchases: updatedCustomerPurchases,
      customers: updatedCustomers,
    }));
  },

  stockLevels: seedStockLevels,
  stockHistory: seedStockHistory,
  adjustStock: (fuelType, amount, reason, recordedBy) => {
    const histEntry: StockHistoryEntry = {
      id: `hist${Date.now()}`,
      date: new Date().toISOString(),
      fuelType,
      changeAmount: amount,
      reason,
      recordedBy,
      type: 'adjustment',
    };
    set(state => ({
      stockLevels: state.stockLevels.map(s =>
        s.fuelType === fuelType
          ? { ...s, currentLevel: Math.max(0, s.currentLevel + amount) }
          : s
      ),
      stockHistory: [histEntry, ...state.stockHistory],
    }));
  },
  updateThreshold: (fuelType, threshold) => {
    set(state => ({
      stockLevels: state.stockLevels.map(s =>
        s.fuelType === fuelType ? { ...s, threshold } : s
      ),
    }));
  },

  staff: seedStaff,
  addStaff: (staffData) => {
    const newStaff: Staff = { id: `s${Date.now()}`, ...staffData };
    set(state => ({ staff: [...state.staff, newStaff] }));
  },
  updateStaff: (id, updates) => {
    set(state => ({
      staff: state.staff.map(s => s.id === id ? { ...s, ...updates } : s),
    }));
  },

  shifts: seedShifts,
  addShift: (shiftData) => {
    const newShift: Shift = { id: `sh${Date.now()}`, ...shiftData };
    set(state => ({ shifts: [...state.shifts, newShift] }));
  },
  updateShiftStatus: (id, status) => {
    set(state => ({
      shifts: state.shifts.map(s => s.id === id ? { ...s, status } : s),
    }));
  },

  customers: seedCustomers,
  customerPurchases: seedCustomerPurchases,
  addCustomer: (customerData) => {
    const newCustomer: Customer = {
      id: `c${Date.now()}`,
      registrationDate: new Date().toISOString().split('T')[0],
      totalPurchaseVolume: 0,
      loyaltyPoints: 0,
      ...customerData,
    };
    set(state => ({ customers: [...state.customers, newCustomer] }));
  },
  redeemPoints: (customerId, points) => {
    set(state => ({
      customers: state.customers.map(c =>
        c.id === customerId
          ? { ...c, loyaltyPoints: Math.max(0, c.loyaltyPoints - points) }
          : c
      ),
    }));
  },

  invoices: seedInvoices,
  toggleInvoiceStatus: (id) => {
    set(state => ({
      invoices: state.invoices.map(inv =>
        inv.id === id
          ? { ...inv, status: inv.status === 'Paid' ? 'Unpaid' : 'Paid' as InvoiceStatus }
          : inv
      ),
    }));
  },

  suppliers: seedSuppliers,
  addSupplier: (supplierData) => {
    const newSupplier: Supplier = { id: `sup${Date.now()}`, ...supplierData };
    set(state => ({ suppliers: [...state.suppliers, newSupplier] }));
  },
  updateSupplier: (id, updates) => {
    set(state => ({
      suppliers: state.suppliers.map(s => s.id === id ? { ...s, ...updates } : s),
    }));
  },

  purchaseOrders: seedPurchaseOrders,
  addPurchaseOrder: (orderData) => {
    const newOrder: PurchaseOrder = { id: `po${Date.now()}`, ...orderData };
    set(state => ({ purchaseOrders: [...state.purchaseOrders, newOrder] }));
  },
  updateOrderStatus: (id, status) => {
    const order = get().purchaseOrders.find(o => o.id === id);
    if (status === 'Delivered' && order) {
      const histEntry: StockHistoryEntry = {
        id: `hist${Date.now()}`,
        date: new Date().toISOString(),
        fuelType: order.fuelType,
        changeAmount: order.quantityOrdered,
        reason: `Delivery from ${order.supplierName}`,
        recordedBy: 'System',
        type: 'purchase',
      };
      set(state => ({
        purchaseOrders: state.purchaseOrders.map(o => o.id === id ? { ...o, status } : o),
        stockLevels: state.stockLevels.map(s =>
          s.fuelType === order.fuelType
            ? { ...s, currentLevel: Math.min(s.capacity, s.currentLevel + order.quantityOrdered) }
            : s
        ),
        stockHistory: [histEntry, ...state.stockHistory],
      }));
    } else {
      set(state => ({
        purchaseOrders: state.purchaseOrders.map(o => o.id === id ? { ...o, status } : o),
      }));
    }
  },

  expenses: seedExpenses,
  addExpense: (expenseData) => {
    const newExpense: Expense = { id: `exp${Date.now()}`, ...expenseData };
    set(state => ({ expenses: [newExpense, ...state.expenses] }));
  },
}));
