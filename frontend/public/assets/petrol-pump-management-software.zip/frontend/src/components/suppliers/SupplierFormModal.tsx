import { useState, useEffect } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { Supplier, FuelType } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
  editingSupplier: Supplier | null;
}

const ALL_FUEL_TYPES: FuelType[] = ['Petrol', 'Diesel', 'Premium'];

export default function SupplierFormModal({ open, onClose, editingSupplier }: Props) {
  const addSupplier = useAppStore(s => s.addSupplier);
  const updateSupplier = useAppStore(s => s.updateSupplier);

  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [fuelTypes, setFuelTypes] = useState<FuelType[]>(['Petrol']);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editingSupplier) {
      setName(editingSupplier.name);
      setContact(editingSupplier.contact);
      setFuelTypes(editingSupplier.fuelTypesSupplied);
    } else {
      setName('');
      setContact('');
      setFuelTypes(['Petrol']);
    }
  }, [editingSupplier, open]);

  const toggleFuelType = (ft: FuelType) => {
    setFuelTypes(prev =>
      prev.includes(ft) ? prev.filter(f => f !== ft) : [...prev, ft]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast.error('Supplier name is required'); return; }
    if (fuelTypes.length === 0) { toast.error('Select at least one fuel type'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    if (editingSupplier) {
      updateSupplier(editingSupplier.id, { name, contact, fuelTypesSupplied: fuelTypes });
      toast.success('Supplier updated');
    } else {
      addSupplier({ name, contact, fuelTypesSupplied: fuelTypes });
      toast.success('Supplier added');
    }
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">
            {editingSupplier ? 'Edit Supplier' : 'Add Supplier'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Supplier Name *</Label>
            <Input
              value={name}
              onChange={e => setName(e.target.value)}
              required
              placeholder="e.g. PetroSupply Co."
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Contact</Label>
            <Input
              value={contact}
              onChange={e => setContact(e.target.value)}
              placeholder="Phone or email"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-2 block">Fuel Types Supplied *</Label>
            <div className="flex gap-4">
              {ALL_FUEL_TYPES.map(ft => (
                <div key={ft} className="flex items-center gap-2">
                  <Checkbox
                    id={`ft-${ft}`}
                    checked={fuelTypes.includes(ft)}
                    onCheckedChange={() => toggleFuelType(ft)}
                    className="border-navy-600 data-[state=checked]:bg-amber data-[state=checked]:border-amber"
                  />
                  <Label htmlFor={`ft-${ft}`} className="text-foreground text-sm cursor-pointer">{ft}</Label>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : editingSupplier ? 'Update' : 'Add Supplier'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
