import { useState } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { FuelType, OrderStatus } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function PurchaseOrderFormModal({ open, onClose }: Props) {
  const addPurchaseOrder = useAppStore(s => s.addPurchaseOrder);
  const suppliers = useAppStore(s => s.suppliers);

  const today = new Date().toISOString().split('T')[0];
  const nextWeek = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];

  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [fuelType, setFuelType] = useState<FuelType>('Petrol');
  const [quantity, setQuantity] = useState('');
  const [pricePerLiter, setPricePerLiter] = useState('85.00');
  const [orderDate, setOrderDate] = useState(today);
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState(nextWeek);
  const [status, setStatus] = useState<OrderStatus>('Pending');
  const [saving, setSaving] = useState(false);

  const qty = parseFloat(quantity) || 0;
  const price = parseFloat(pricePerLiter) || 0;
  const totalCost = qty * price;

  const selectedSupplier = suppliers.find(s => s.id === supplierId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierId) { toast.error('Select a supplier'); return; }
    if (!qty || qty <= 0) { toast.error('Enter a valid quantity'); return; }
    if (expectedDeliveryDate < orderDate) { toast.error('Delivery date must be after order date'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    addPurchaseOrder({
      supplierId,
      supplierName: selectedSupplier?.name || 'Unknown',
      fuelType,
      quantityOrdered: qty,
      pricePerLiter: price,
      totalCost,
      orderDate,
      expectedDeliveryDate,
      status,
    });
    toast.success('Purchase order created');
    setSaving(false);
    setQuantity('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Create Purchase Order</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Supplier *</Label>
            <Select value={supplierId} onValueChange={setSupplierId}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue placeholder="Select supplier" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                {suppliers.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Fuel Type *</Label>
            <Select value={fuelType} onValueChange={v => setFuelType(v as FuelType)}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                {(selectedSupplier?.fuelTypesSupplied ?? ['Petrol', 'Diesel', 'Premium']).map(ft => (
                  <SelectItem key={ft} value={ft}>{ft}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Quantity (Liters) *</Label>
              <Input
                type="number"
                min="1"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
                placeholder="e.g. 10000"
                required
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Price per Liter (&#8377;)</Label>
              <Input
                type="number"
                min="0.01"
                step="0.01"
                value={pricePerLiter}
                onChange={e => setPricePerLiter(e.target.value)}
                required
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Order Date</Label>
              <Input
                type="date"
                value={orderDate}
                onChange={e => setOrderDate(e.target.value)}
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Expected Delivery</Label>
              <Input
                type="date"
                value={expectedDeliveryDate}
                onChange={e => setExpectedDeliveryDate(e.target.value)}
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
          </div>

          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Status</Label>
            <Select value={status} onValueChange={v => setStatus(v as OrderStatus)}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Delivered">Delivered</SelectItem>
                <SelectItem value="Cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Total Cost */}
          <div className="bg-navy-800 rounded-xl p-4 border border-amber/30">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground text-sm">Total Order Cost</span>
              <span className="font-display text-2xl text-amber">
                &#8377;{totalCost.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating...</> : 'Create Order'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
