import { useState } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Star } from 'lucide-react';
import { toast } from 'sonner';
import type { Customer } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
  customer: Customer;
}

export default function RedeemPointsModal({ open, onClose, customer }: Props) {
  const redeemPoints = useAppStore(s => s.redeemPoints);
  const [points, setPoints] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const pts = parseInt(points);
    if (!pts || pts <= 0) { toast.error('Enter a valid number of points'); return; }
    if (pts > customer.loyaltyPoints) { toast.error(`Cannot redeem more than ${customer.loyaltyPoints} points`); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    redeemPoints(customer.id, pts);
    toast.success(`${pts} points redeemed for ${customer.name}`);
    setSaving(false);
    setPoints(''); setNote('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Redeem Loyalty Points</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-amber/10 rounded-xl p-4 border border-amber/30 flex items-center gap-3">
            <Star className="w-5 h-5 text-amber" />
            <div>
              <p className="text-xs text-muted-foreground">Available Balance</p>
              <p className="font-display text-2xl text-amber">{customer.loyaltyPoints.toLocaleString()} pts</p>
            </div>
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Points to Redeem</Label>
            <Input
              type="number"
              min="1"
              max={customer.loyaltyPoints}
              value={points}
              onChange={e => setPoints(e.target.value)}
              required
              placeholder={`Max: ${customer.loyaltyPoints}`}
              className="bg-navy-800 border-navy-600 text-foreground"
            />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Redemption Note</Label>
            <Textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Reason for redemption..."
              rows={2}
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground resize-none"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">Cancel</Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Redeeming...</> : 'Redeem Points'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
