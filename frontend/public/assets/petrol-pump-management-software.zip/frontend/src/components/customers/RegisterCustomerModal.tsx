import { useState } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function RegisterCustomerModal({ open, onClose }: Props) {
  const addCustomer = useAppStore(s => s.addCustomer);
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !vehicleNumber.trim()) { toast.error('Name and vehicle number are required'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    addCustomer({ name, contact, vehicleNumber });
    toast.success(`Customer ${name} registered successfully`);
    setSaving(false);
    setName(''); setContact(''); setVehicleNumber('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Register New Customer</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Full Name *</Label>
            <Input value={name} onChange={e => setName(e.target.value)} required placeholder="Customer full name"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground" />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Contact</Label>
            <Input value={contact} onChange={e => setContact(e.target.value)} placeholder="Phone or email"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground" />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Vehicle Number *</Label>
            <Input value={vehicleNumber} onChange={e => setVehicleNumber(e.target.value.toUpperCase())} required placeholder="e.g. ABC-1234"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground font-mono" />
          </div>
          <p className="text-xs text-muted-foreground">Customer will earn 1 loyalty point per liter purchased.</p>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">Cancel</Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Registering...</> : 'Register Customer'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
