import { useState, useEffect } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { Staff, StaffStatus } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
  editingStaff: Staff | null;
}

export default function StaffFormModal({ open, onClose, editingStaff }: Props) {
  const addStaff = useAppStore(s => s.addStaff);
  const updateStaff = useAppStore(s => s.updateStaff);

  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [contact, setContact] = useState('');
  const [hireDate, setHireDate] = useState(new Date().toISOString().split('T')[0]);
  const [status, setStatus] = useState<StaffStatus>('Active');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editingStaff) {
      setName(editingStaff.name);
      setRole(editingStaff.role);
      setContact(editingStaff.contact);
      setHireDate(editingStaff.hireDate);
      setStatus(editingStaff.status);
    } else {
      setName(''); setRole(''); setContact('');
      setHireDate(new Date().toISOString().split('T')[0]);
      setStatus('Active');
    }
  }, [editingStaff, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !role.trim()) { toast.error('Name and role are required'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    if (editingStaff) {
      updateStaff(editingStaff.id, { name, role, contact, hireDate, status });
      toast.success('Staff member updated');
    } else {
      addStaff({ name, role, contact, hireDate, status });
      toast.success('Staff member added');
    }
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">
            {editingStaff ? 'Edit Staff Member' : 'Add Staff Member'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Full Name *</Label>
            <Input value={name} onChange={e => setName(e.target.value)} required placeholder="Enter full name"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground" />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Role *</Label>
            <Input value={role} onChange={e => setRole(e.target.value)} required placeholder="e.g. Pump Attendant, Cashier"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground" />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Contact</Label>
            <Input value={contact} onChange={e => setContact(e.target.value)} placeholder="Phone or email"
              className="bg-navy-800 border-navy-600 text-foreground placeholder:text-muted-foreground" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Hire Date</Label>
              <Input type="date" value={hireDate} onChange={e => setHireDate(e.target.value)}
                className="bg-navy-800 border-navy-600 text-foreground" />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Status</Label>
              <Select value={status} onValueChange={v => setStatus(v as StaffStatus)}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">Cancel</Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : editingStaff ? 'Update' : 'Add Staff'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
