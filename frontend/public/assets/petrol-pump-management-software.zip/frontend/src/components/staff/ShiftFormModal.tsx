import { useState } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { ShiftStatus } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function ShiftFormModal({ open, onClose }: Props) {
  const addShift = useAppStore(s => s.addShift);
  const staff = useAppStore(s => s.staff).filter(s => s.status === 'Active');

  const [staffId, setStaffId] = useState(staff[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('06:00');
  const [endTime, setEndTime] = useState('14:00');
  const [pumpNumber, setPumpNumber] = useState('1');
  const [status, setStatus] = useState<ShiftStatus>('Scheduled');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffId) { toast.error('Select a staff member'); return; }
    if (startTime >= endTime) { toast.error('End time must be after start time'); return; }
    const selectedStaff = staff.find(s => s.id === staffId);
    setSaving(true);
    await new Promise(r => setTimeout(r, 300));
    addShift({
      staffId,
      staffName: selectedStaff?.name || 'Unknown',
      date,
      startTime,
      endTime,
      pumpNumber: parseInt(pumpNumber),
      status,
    });
    toast.success('Shift created successfully');
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Create Shift</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Staff Member *</Label>
            <Select value={staffId} onValueChange={setStaffId}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue placeholder="Select staff" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                {staff.map(s => <SelectItem key={s.id} value={s.id}>{s.name} — {s.role}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Date</Label>
            <Input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="bg-navy-800 border-navy-600 text-foreground" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Start Time</Label>
              <Input type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
                className="bg-navy-800 border-navy-600 text-foreground" />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">End Time</Label>
              <Input type="time" value={endTime} onChange={e => setEndTime(e.target.value)}
                className="bg-navy-800 border-navy-600 text-foreground" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Pump Number</Label>
              <Select value={pumpNumber} onValueChange={setPumpNumber}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  {[1, 2, 3, 4].map(n => <SelectItem key={n} value={String(n)}>Pump {n}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Status</Label>
              <Select value={status} onValueChange={v => setStatus(v as ShiftStatus)}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  <SelectItem value="Scheduled">Scheduled</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} className="border-navy-600 text-foreground hover:bg-navy-600">Cancel</Button>
            <Button type="submit" disabled={saving} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating...</> : 'Create Shift'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
