import { useRef } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Printer, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import type { Invoice } from '../../types';

interface Props {
  invoice: Invoice;
  onClose: () => void;
}

export default function InvoiceDetailModal({ invoice, onClose }: Props) {
  const toggleInvoiceStatus = useAppStore(s => s.toggleInvoiceStatus);
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const handleToggleStatus = () => {
    toggleInvoiceStatus(invoice.id);
    toast.success(`Invoice marked as ${invoice.status === 'Paid' ? 'Unpaid' : 'Paid'}`);
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Invoice Details</DialogTitle>
        </DialogHeader>

        <div ref={printRef} className="space-y-4">
          {/* Invoice Header */}
          <div className="flex justify-between items-start">
            <div>
              <h2 className="font-display text-2xl text-amber">PUMPPRO MANAGER</h2>
              <p className="text-muted-foreground text-xs">Petrol Station Management</p>
            </div>
            <div className="text-right">
              <p className="font-mono text-sm text-foreground font-bold">{invoice.invoiceNumber}</p>
              <p className="text-muted-foreground text-xs">{new Date(invoice.date).toLocaleDateString('en-IN')}</p>
              <Badge
                variant="outline"
                className={invoice.status === 'Paid'
                  ? 'mt-1 bg-fuel-petrol/20 text-fuel-petrol border-fuel-petrol/30'
                  : 'mt-1 bg-destructive/20 text-destructive border-destructive/30'}
              >
                {invoice.status}
              </Badge>
            </div>
          </div>

          {/* Customer */}
          <div className="bg-navy-800 rounded-xl p-4 border border-navy-600">
            <p className="text-muted-foreground text-xs mb-1">Bill To</p>
            <p className="text-foreground font-semibold">{invoice.customerName}</p>
            <p className="text-muted-foreground text-xs">Payment: {invoice.paymentMethod}</p>
          </div>

          {/* Line Items */}
          <div className="border border-navy-600 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-navy-800 border-b border-navy-600">
                  <th className="text-left text-muted-foreground py-2 px-3">Description</th>
                  <th className="text-right text-muted-foreground py-2 px-3">Qty</th>
                  <th className="text-right text-muted-foreground py-2 px-3">Rate</th>
                  <th className="text-right text-muted-foreground py-2 px-3">Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-navy-600">
                  <td className="py-2 px-3 text-foreground">{invoice.fuelType} Fuel</td>
                  <td className="py-2 px-3 text-right text-foreground">{invoice.quantity}L</td>
                  <td className="py-2 px-3 text-right text-foreground">
                    &#8377;{invoice.pricePerLiter.toFixed(2)}/L
                  </td>
                  <td className="py-2 px-3 text-right text-foreground">
                    &#8377;{invoice.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>&#8377;{invoice.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Tax (10%)</span>
              <span>&#8377;{invoice.tax.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between font-bold text-foreground border-t border-navy-600 pt-2">
              <span className="font-display text-lg">TOTAL</span>
              <span className="font-display text-lg text-amber">
                &#8377;{invoice.total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={handleToggleStatus}
            className="border-navy-600 text-foreground hover:bg-navy-600"
          >
            {invoice.status === 'Paid'
              ? <><XCircle className="w-4 h-4 mr-2 text-destructive" />Mark Unpaid</>
              : <><CheckCircle className="w-4 h-4 mr-2 text-fuel-petrol" />Mark Paid</>
            }
          </Button>
          <Button variant="outline" onClick={handlePrint} className="border-navy-600 text-foreground hover:bg-navy-600">
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button onClick={onClose} className="bg-amber text-navy-900 hover:bg-amber-light font-semibold">
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
