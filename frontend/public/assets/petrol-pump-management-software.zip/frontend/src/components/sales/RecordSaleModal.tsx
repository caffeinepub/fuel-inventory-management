import { useState } from 'react';
import { useAppStore } from '../../store/appStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { FuelType, PaymentMethod } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
}

const defaultPrices: Record<FuelType, string> = {
  Petrol: '102.50',
  Diesel: '89.75',
  Premium: '110.00',
};

export default function RecordSaleModal({ open, onClose }: Props) {
  const addSale = useAppStore(s => s.addSale);
  const staff = useAppStore(s => s.staff).filter(s => s.status === 'Active');
  const customers = useAppStore(s => s.customers);
  const stockLevels = useAppStore(s => s.stockLevels);

  const [fuelType, setFuelType] = useState<FuelType>('Petrol');
  const [quantity, setQuantity] = useState('');
  const [pricePerLiter, setPricePerLiter] = useState(defaultPrices['Petrol']);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [pumpNumber, setPumpNumber] = useState('1');
  const [staffId, setStaffId] = useState(staff[0]?.id || '');
  const [customerId, setCustomerId] = useState('');
  const [saving, setSaving] = useState(false);

  const qty = parseFloat(quantity) || 0;
  const price = parseFloat(pricePerLiter) || 0;
  const total = qty * price;
  const currentStock = stockLevels.find(s => s.fuelType === fuelType);

  const handleFuelChange = (ft: FuelType) => {
    setFuelType(ft);
    setPricePerLiter(defaultPrices[ft]);
  };

  const handleClose = () => {
    setQuantity('');
    setCustomerId('');
    setFuelType('Petrol');
    setPricePerLiter(defaultPrices['Petrol']);
    setPaymentMethod('Cash');
    setPumpNumber('1');
    setStaffId(staff[0]?.id || '');
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedQty = parseFloat(quantity);
    if (!parsedQty || parsedQty <= 0) {
      toast.error('Enter a valid quantity');
      return;
    }
    if (currentStock && parsedQty > currentStock.currentLevel) {
      toast.error(`Insufficient stock. Available: ${currentStock.currentLevel.toLocaleString('en-IN')}L`);
      return;
    }
    const parsedPrice = parseFloat(pricePerLiter);
    if (!parsedPrice || parsedPrice <= 0) {
      toast.error('Enter a valid price per liter');
      return;
    }
    const selectedStaff = staff.find(s => s.id === staffId);
    if (!selectedStaff) {
      toast.error('Please select a staff member');
      return;
    }
    const selectedCustomer = customerId ? customers.find(c => c.id === customerId) : undefined;

    setSaving(true);
    try {
      await new Promise(r => setTimeout(r, 300));
      addSale({
        date: new Date().toISOString(),
        fuelType,
        quantity: parsedQty,
        pricePerLiter: parsedPrice,
        totalAmount: parseFloat((parsedQty * parsedPrice).toFixed(2)),
        paymentMethod,
        pumpNumber: parseInt(pumpNumber),
        staffId,
        staffName: selectedStaff.name,
        customerId: customerId || undefined,
        customerName: selectedCustomer?.name,
      });
      toast.success(`Sale recorded: ${parsedQty}L ${fuelType} \u2014 \u20B9${(parsedQty * parsedPrice).toFixed(2)}`);
      handleClose();
    } catch (err: any) {
      console.error('Error recording sale:', err);
      toast.error(err?.message || 'Failed to record sale. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => { if (!isOpen) handleClose(); }}>
      <DialogContent className="bg-navy-700 border-navy-600 text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-amber">Record Fuel Sale</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Fuel Type</Label>
              <Select value={fuelType} onValueChange={v => handleFuelChange(v as FuelType)}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  <SelectItem value="Petrol">Petrol</SelectItem>
                  <SelectItem value="Diesel">Diesel</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                </SelectContent>
              </Select>
              {currentStock && (
                <p className="text-xs text-muted-foreground mt-1">
                  Stock: {currentStock.currentLevel.toLocaleString('en-IN')}L
                </p>
              )}
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Pump Number</Label>
              <Select value={pumpNumber} onValueChange={setPumpNumber}>
                <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                  {[1, 2, 3, 4].map(n => (
                    <SelectItem key={n} value={String(n)}>Pump {n}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Quantity (Liters)</Label>
              <Input
                type="number"
                min="0.1"
                step="0.1"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
                placeholder="0.0"
                required
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Price per Liter (&#8377;)</Label>
              <Input
                type="number"
                min="0.01"
                step="0.01"
                value={pricePerLiter}
                onChange={e => setPricePerLiter(e.target.value)}
                required
                className="bg-navy-800 border-navy-600 text-foreground"
              />
            </div>
          </div>

          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Payment Method</Label>
            <Select value={paymentMethod} onValueChange={v => setPaymentMethod(v as PaymentMethod)}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                <SelectItem value="Cash">Cash</SelectItem>
                <SelectItem value="Card">Card</SelectItem>
                <SelectItem value="Credit">Credit</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Staff Member</Label>
            <Select value={staffId} onValueChange={setStaffId}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue placeholder="Select staff" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                {staff.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Customer (Optional)</Label>
            <Select value={customerId} onValueChange={setCustomerId}>
              <SelectTrigger className="bg-navy-800 border-navy-600 text-foreground">
                <SelectValue placeholder="Walk-in customer" />
              </SelectTrigger>
              <SelectContent className="bg-navy-700 border-navy-600 text-foreground">
                <SelectItem value="">Walk-in</SelectItem>
                {customers.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.name} ({c.vehicleNumber})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Total */}
          <div className="bg-navy-800 rounded-xl p-4 border border-amber/30">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground text-sm">Total Amount</span>
              <span className="font-display text-2xl text-amber">
                &#8377;{total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="border-navy-600 text-foreground hover:bg-navy-600"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="bg-amber text-navy-900 hover:bg-amber-light font-semibold"
            >
              {saving
                ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Recording...</>
                : 'Record Sale'
              }
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
