import { useNavigate, useRouterState } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { LogOut, User, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import type { UserProfile } from '../../backend';
import { useAppStore } from '../../store/appStore';

const pageTitles: Record<string, string> = {
  '/': 'Dashboard',
  '/sales': 'Fuel Sales',
  '/inventory': 'Inventory & Stock',
  '/staff': 'Staff & Shifts',
  '/customers': 'Customers',
  '/billing': 'Billing & Invoicing',
  '/reports': 'Reports & Analytics',
  '/suppliers': 'Suppliers',
  '/expenses': 'Expense Tracking',
};

interface TopBarProps {
  profile: UserProfile | null | undefined;
  sidebarCollapsed: boolean;
}

export default function TopBar({ profile }: TopBarProps) {
  const { clear, identity } = useInternetIdentity();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;
  const stockLevels = useAppStore(s => s.stockLevels);

  const lowStockCount = stockLevels.filter(s => s.currentLevel < s.threshold).length;

  const pageTitle = Object.entries(pageTitles).find(([path]) =>
    path === '/' ? currentPath === '/' : currentPath.startsWith(path)
  )?.[1] || 'PumpPro';

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
    navigate({ to: '/login' });
  };

  const initials = profile?.name
    ? profile.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  return (
    <header className="h-16 bg-navy-800 border-b border-navy-600 flex items-center justify-between px-6 flex-shrink-0 sticky top-0 z-10">
      <div>
        <h1 className="font-display text-xl text-foreground tracking-wide">{pageTitle}</h1>
        <p className="text-xs text-muted-foreground">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      <div className="flex items-center gap-3">
        {/* Low stock alert bell */}
        {lowStockCount > 0 && (
          <button
            onClick={() => navigate({ to: '/inventory' })}
            className="relative w-9 h-9 rounded-xl bg-navy-700 border border-navy-600 flex items-center justify-center text-muted-foreground hover:text-amber hover:border-amber transition-colors"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full text-xs text-white flex items-center justify-center font-bold">
              {lowStockCount}
            </span>
          </button>
        )}

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-navy-700 border border-navy-600 hover:border-amber transition-colors">
              <Avatar className="w-7 h-7">
                <AvatarFallback className="bg-amber text-navy-900 text-xs font-bold">{initials}</AvatarFallback>
              </Avatar>
              {profile && <span className="text-sm text-foreground font-medium hidden sm:block">{profile.name}</span>}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-navy-700 border-navy-600 text-foreground w-48">
            <DropdownMenuLabel className="text-muted-foreground text-xs">
              {profile?.name || 'User'}
              {profile?.role && <span className="block text-amber">{profile.role}</span>}
            </DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-navy-600" />
            <DropdownMenuItem
              onClick={handleLogout}
              className="text-destructive hover:bg-navy-600 cursor-pointer"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
