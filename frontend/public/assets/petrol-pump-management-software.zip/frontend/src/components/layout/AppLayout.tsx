import { useState, useEffect } from 'react';
import { Outlet, useNavigate } from '@tanstack/react-router';
import { useInternetIdentity } from '../../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../../hooks/useQueries';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import { Loader2 } from 'lucide-react';

export default function AppLayout() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: profile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const navigate = useNavigate();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    return localStorage.getItem('sidebar-collapsed') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('sidebar-collapsed', String(sidebarCollapsed));
  }, [sidebarCollapsed]);

  useEffect(() => {
    if (isInitializing) return;
    if (!identity) {
      navigate({ to: '/login' });
      return;
    }
    if (!profileLoading && isFetched && profile === null) {
      navigate({ to: '/profile-setup' });
    }
  }, [identity, isInitializing, profile, profileLoading, isFetched, navigate]);

  if (isInitializing || (identity && profileLoading)) {
    return (
      <div className="min-h-screen bg-navy-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-amber animate-spin mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Loading PumpPro...</p>
        </div>
      </div>
    );
  }

  if (!identity) return null;

  return (
    <div className="flex h-screen bg-navy-900 overflow-hidden">
      <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(c => !c)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopBar profile={profile} sidebarCollapsed={sidebarCollapsed} />
        <main className="flex-1 overflow-y-auto scrollbar-thin p-6">
          <Outlet />
        </main>
        <footer className="px-6 py-3 border-t border-navy-600 bg-navy-800 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} PumpPro Manager. Built with{' '}
            <span className="text-amber">♥</span> using{' '}
            <a
              href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'pumppro-manager')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}
