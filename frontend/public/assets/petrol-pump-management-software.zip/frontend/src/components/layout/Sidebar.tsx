import { Link, useRouterState } from '@tanstack/react-router';
import {
  LayoutDashboard, Fuel, Package, Users, UserCheck,
  FileText, BarChart3, Truck, Receipt, ChevronLeft, ChevronRight
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const navItems: NavItem[] = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/sales', label: 'Fuel Sales', icon: Fuel },
  { path: '/inventory', label: 'Inventory', icon: Package },
  { path: '/staff', label: 'Staff & Shifts', icon: UserCheck },
  { path: '/customers', label: 'Customers', icon: Users },
  { path: '/billing', label: 'Billing', icon: FileText },
  { path: '/reports', label: 'Reports', icon: BarChart3 },
  { path: '/suppliers', label: 'Suppliers', icon: Truck },
  { path: '/expenses', label: 'Expenses', icon: Receipt },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  const isActive = (path: string) => {
    if (path === '/') return currentPath === '/';
    return currentPath.startsWith(path);
  };

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={`flex flex-col bg-navy-900 border-r border-navy-600 transition-all duration-300 ease-in-out flex-shrink-0 ${
          collapsed ? 'w-16' : 'w-60'
        }`}
      >
        {/* Header */}
        <div className={`flex items-center border-b border-navy-600 h-16 px-3 ${collapsed ? 'justify-center' : 'justify-between'}`}>
          {!collapsed && (
            <div className="flex items-center gap-2 min-w-0">
              <img
                src="/assets/generated/pump-logo.dim_128x128.png"
                alt="PumpPro"
                className="w-8 h-8 object-contain flex-shrink-0"
              />
              <span className="font-display text-xl text-amber tracking-wider truncate">PUMPPRO</span>
            </div>
          )}
          {collapsed && (
            <img
              src="/assets/generated/pump-logo.dim_128x128.png"
              alt="PumpPro"
              className="w-8 h-8 object-contain"
            />
          )}
          <button
            onClick={onToggle}
            className={`flex-shrink-0 w-7 h-7 rounded-lg bg-navy-700 hover:bg-navy-600 border border-navy-600 flex items-center justify-center text-muted-foreground hover:text-amber transition-colors ${collapsed ? 'hidden' : ''}`}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Expand button when collapsed */}
        {collapsed && (
          <button
            onClick={onToggle}
            className="mx-auto mt-2 w-8 h-8 rounded-lg bg-navy-700 hover:bg-navy-600 border border-navy-600 flex items-center justify-center text-muted-foreground hover:text-amber transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}

        {/* Navigation */}
        <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto scrollbar-thin">
          {navItems.map(({ path, label, icon: Icon }) => {
            const active = isActive(path);
            const linkEl = (
              <Link
                to={path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 group ${
                  active
                    ? 'bg-amber text-navy-900 font-semibold shadow-amber'
                    : 'text-muted-foreground hover:bg-navy-700 hover:text-foreground'
                } ${collapsed ? 'justify-center' : ''}`}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-navy-900' : 'text-muted-foreground group-hover:text-amber'}`} />
                {!collapsed && <span className="text-sm truncate">{label}</span>}
              </Link>
            );

            if (collapsed) {
              return (
                <Tooltip key={path}>
                  <TooltipTrigger asChild>{linkEl}</TooltipTrigger>
                  <TooltipContent side="right" className="bg-navy-700 text-foreground border-navy-600">
                    {label}
                  </TooltipContent>
                </Tooltip>
              );
            }
            return <div key={path}>{linkEl}</div>;
          })}
        </nav>

        {/* Footer */}
        {!collapsed && (
          <div className="p-3 border-t border-navy-600">
            <p className="text-xs text-muted-foreground text-center">v1.0.0</p>
          </div>
        )}
      </aside>
    </TooltipProvider>
  );
}
