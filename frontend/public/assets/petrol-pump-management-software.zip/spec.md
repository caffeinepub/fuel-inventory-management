# Specification

## Summary
**Goal:** Fix the Indian Rupee symbol (₹) display across all pages and resolve the "Something went wrong!" error when submitting the Record Sale modal in the Petrol Pump Manager app.

**Planned changes:**
- Replace all dollar sign ($) currency symbols with the ₹ symbol across all frontend pages and components (Dashboard, FuelSales, Billing, Reports, Expenses, CustomerDetail) and all modal dialogs that display monetary values
- Ensure the ₹ character is correctly encoded (UTF-8) and renders visibly everywhere currency is shown
- Fix runtime errors in the RecordSaleModal submit handler, including store action calls, stock validation logic, data shape mismatches, and null/undefined reference errors
- Ensure successful sale submission decrements stock correctly, closes the modal, and displays the new sale in the FuelSales list
- Add a clear validation message when stock is insufficient instead of a generic error

**User-visible outcome:** The ₹ symbol displays correctly everywhere in the app, and users can successfully record fuel sales through the Record Sale modal without errors.
